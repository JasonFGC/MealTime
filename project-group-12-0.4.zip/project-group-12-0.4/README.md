# Meal Time
---
## Group 12 Members
- Diery Fall
- Jas Dhindsa
- Jason Lam
- Jordan Na
- Ryan Rambali

---

## Link Figma Design File: 

https://www.figma.com/file/5PsDgIA7xMIzoMCd8Zu9Z6/Meal-Time?node-id=0%3A1&t=2oxcRG4glTPma3sB-1

---

## Log in as Admin
**Email:** mealtimeadmin@rambolps.ca

**Password:** Test1234

---

| Account Type| Email                     | Password| 
| ----------- | -----------               | -----
| Cook        | alexjones@gmail.com       |Test1234
| Cook        | elizabethabbott@gmail.com |Test1234
| Cook        | reilyann@gmail.com        |Test1234
| Cook        | lucassmith@gmail.com      |Test1234
| Cook        | jasonadkins@gmail.com     |Test1234
| Cook        | kayjr@gmail.com           |Test1234
| Cook        | lillyjayde@gmail.com      |Test1234
| Cook        | isaacanderson@gmail.com   |Test1234
| Cook        | ashleyarnold@gmail.com    |Test1234
| Client      | client@gmail.com          |Test1234
| Cook        | lucyadams@gmail.com       |Test1234
| Cook        | cookz@gmail.com           |Test1234
| Client      | salileva@gmail.com        |Test1234
| Client      | jaydenjackson@gmail.com   |Test1234
| Client      | ezranova@gmail.com        |Test1234
| Client      | mianewman@gmail.com       |Test1234



## IMPORTANT NOTES WHEN REGISTERING

1. Credit Card Number **IS** Checked. Either use a real credit card, or use the number **555555555555** (<-- The number "5" 16 times).
2. Postal Code **IS** Checked. Use a **REAL** postal code (Does not need to match the rest of the address).
3. Fields such as **CVV** and **Credit Card Expiry** need the be the correct length (4 digits for Credit Card Expiry & 3 digits for CVV).

---

## IMPORTANT NOTES WHEN ADDING MEALS

1. Add Ingredients Separately 
2. Add Allergens Separately 
3. Add Rest Of Meal

---

## OTHER NOTES

1. The Database takes some time to return callbacks when on a slow internet connection when changing state as a cook. 
You might need to click the | Accept | Reject | Done | buttons a couple of time for it to go through 



