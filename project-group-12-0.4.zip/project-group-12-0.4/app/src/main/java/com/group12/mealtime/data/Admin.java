package com.group12.mealtime.data;

import java.util.ArrayList;

public class Admin {

    private String id;
    private String firstName;
    private String lastName;
    private ArrayList<String> complaintInbox;
    private String picture;

    public Admin() {};

    public Admin(String id, String firstName, String lastName, String email, String picture) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.complaintInbox = new ArrayList<String>();
        this.picture = picture;
    }

    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public ArrayList<String> getComplaintInbox() {
        return complaintInbox;
    }

    public String getPicture() {
        return picture;
    }
}
