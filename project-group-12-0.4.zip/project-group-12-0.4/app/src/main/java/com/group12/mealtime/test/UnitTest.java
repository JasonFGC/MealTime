package com.group12.mealtime.test;

import com.group12.mealtime.utils.FormValidator;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class UnitTest {
    @Test
    public void testCreditCardIsInvalid() {
        String invalidCreditCard = "123";
        assertTrue(FormValidator.isInvalidCreditCardNumber(invalidCreditCard));
    }

    @Test
    public void testCreditCardIsValid() {
        String validCreditCard = "4556350681345020";
        assertFalse(FormValidator.isInvalidCreditCardNumber(validCreditCard));
    }

    @Test
    public void testStreetNumberIsInvalid() {
        String invalidStreetNumber = "pine street";
        assertTrue(FormValidator.isInvalidStreetNumber(invalidStreetNumber));
    }

    @Test
    public void testStreetNumberIsValid() {
        String validStreetNumber = "123";
        assertFalse(FormValidator.isInvalidStreetNumber(validStreetNumber));
    }




}
