package com.group12.mealtime.layout.cook;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.databinding.ActivityCookMainBinding;
import com.squareup.picasso.Picasso;

public class CookMain extends AppCompatActivity {

    ActivityCookMainBinding binding;
    private String cookId;
    ImageView profileBtn;
    private FirebaseFirestore db;
    String cookpic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cookId = getIntent().getStringExtra("id");
        binding = ActivityCookMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.bottomNavBar.setSelectedItemId(R.id.cook_home);
        replaceCookFragment(new CookHome());
        binding.bottomNavBar.setOnItemSelectedListener(item -> {
            switch (item.getItemId()){

                case R.id.cook_pending:
                    replaceCookFragment(new CookPending());
                    break;
                case R.id.cook_home:
                    replaceCookFragment(new CookHome());
                    break;
                case R.id.cook_menu:
                    replaceCookFragment(new CookMenu());
                    break;
            }

            return true;
        });


        ImageView profileIcon = findViewById(R.id.ProfileBtn);
        db = FirebaseFirestore.getInstance();


        profileIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent profileIntent = new Intent(CookMain.this, CookProfile.class);
                profileIntent.putExtra("cookId",cookId);
                startActivity(profileIntent);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        profileBtn = findViewById(R.id.ProfileBtn);
        DocumentReference cookRef = db.collection("Cooks").document(cookId);
        cookRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        cookpic = document.get("pic").toString();

                        Picasso.get().load(cookpic).resize(32, 32).centerCrop().into(profileBtn);
                    }
                }
            }
        });
    }

    private void replaceCookFragment(Fragment fragment){
        Bundle bundle = new Bundle();
        bundle.putString("cookId",cookId);
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayoutCook,fragment);
        fragmentTransaction.commit();
    }
}