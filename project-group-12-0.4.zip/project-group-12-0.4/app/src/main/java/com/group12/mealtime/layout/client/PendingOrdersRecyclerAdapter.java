package com.group12.mealtime.layout.client;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Complaint;
import com.group12.mealtime.data.PurchaseRequest;
import com.group12.mealtime.layout.admin.Bridge;
import com.group12.mealtime.layout.admin.DatePickerFragment;
import com.group12.mealtime.utils.TimeTools;
import com.squareup.picasso.Picasso;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Complaint;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PendingOrdersRecyclerAdapter extends RecyclerView.Adapter<PendingOrdersRecyclerAdapter.MyViewHolder> {

    FirebaseFirestore db;
    CollectionReference purchaseRequestsCollection;
    List<PurchaseRequest> pendingList;
    Context context;

    public PendingOrdersRecyclerAdapter(List<PurchaseRequest> pendingList, Context context) {
        this.pendingList = pendingList;
        this.context = context;
        this.db = FirebaseFirestore.getInstance();
        this.purchaseRequestsCollection = db.collection("PurchaseRequests");
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.client_pending_order_card, parent, false);
        PendingOrdersRecyclerAdapter.MyViewHolder holder = new PendingOrdersRecyclerAdapter.MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        PurchaseRequest pr = pendingList.get(position);
        DocumentReference cookRef = db.collection("Cooks").document(pr.getCookId());
        DocumentReference purchaseRef = db.collection("Meals").document(pr.getMealId());



        Calendar orderDate = Calendar.getInstance();
        orderDate.setTime(pendingList.get(position).getOrderDate().toDate());
        int month = orderDate.get(Calendar.MONTH) + 1;
        int day = orderDate.get(Calendar.DAY_OF_MONTH);
        int year = orderDate.get(Calendar.YEAR);
        String dateString = (
                String.format("%02d", month) +
                        " / " + String.format("%02d", day) + " / " +
                        year
        );
        holder.orderDate.setText(dateString);


        Calendar pickupDate = Calendar.getInstance();
        pickupDate.setTime(pendingList.get(position).getPickupTime().toDate());
        long currentTime = Calendar.getInstance().getTimeInMillis();
        long pickupTime = pickupDate.getTimeInMillis();
        long minutes = TimeTools.toMinutes(pickupTime - currentTime);
        if(minutes <= 0) {
            holder.pickupTime.setText((minutes * -1) + " min late");
            holder.pickupTime.setTextColor(Color.RED);
        } else {
            holder.pickupTime.setText(minutes + " min");
        }



        cookRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        String name = document.get("firstName").toString() + " " + document.get("lastName").toString();
                        String pic = document.get("pic").toString();
                        holder.cookName.setText(name);
                        Picasso.get().load(pic).resize(35, 35).centerCrop().into(holder.cookPic);


                    }
                }
            }
        });

        purchaseRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot documentSnapshot = task.getResult();
                    if (documentSnapshot.exists()) {
                        String pic = documentSnapshot.get("pic").toString();
                        Picasso.get().load(pic).resize(100, 100).centerCrop().into(holder.mealImage);
                    }
                }

            }
        });
    }

    public int getItemCount () {
        return pendingList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView cookName;
        TextView pickupTime;
        TextView orderDate;
        ImageView mealImage;
        ImageView cookPic;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cookName = (TextView) itemView.findViewById(R.id.tv_clientPendingOrderCookName);
            pickupTime = (TextView) itemView.findViewById(R.id.tv_clientPendingOrderPickupTime);
            orderDate = (TextView) itemView.findViewById(R.id.tv_clientPendingOrderDate);
            mealImage = (ImageView) itemView.findViewById(R.id.iv_clientPendingOrderMealPic);
            cookPic = (ImageView) itemView.findViewById(R.id.iv_clientPendingOrderCookProfilePic);

        }
    }
}