package com.group12.mealtime.layout.client;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Review;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ReviewRecyclerAdapter extends RecyclerView.Adapter<ReviewRecyclerAdapter.MyViewHolder> {

    private FirebaseFirestore db;
    private List<Review> reviewList;
    private Context context;

    public ReviewRecyclerAdapter(List<Review> reviewList, Context context) {
        this.reviewList = reviewList;
        this.context = context;
        this.db = FirebaseFirestore.getInstance();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.client_review_card, parent, false);

        ReviewRecyclerAdapter.MyViewHolder holder = new ReviewRecyclerAdapter.MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Review review = reviewList.get(position);
        holder.rating.setText(Float.toString((float) (Math.round(review.getRating() * 100.0) / 100.0)));
        holder.reviewDescription.setText(review.getDescription());
        Calendar reviewDate = Calendar.getInstance();
        reviewDate.setTime(review.getDate().toDate());
        int month = reviewDate.get(Calendar.MONTH) + 1;
        int day = reviewDate.get(Calendar.DAY_OF_MONTH);
        int year = reviewDate.get(Calendar.YEAR);
        String dateString = (
                String.format("%02d", month) +
                        " / " + String.format("%02d", day) + " / " +
                        year
        );
        holder.reviewDate.setText(dateString);
        db.collection("Clients").document(review.getClientId()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                DocumentSnapshot clientData = task.getResult();
                Picasso.get().load(clientData.get("picture").toString()).resize(40, 40).centerCrop().into(holder.clientPic);
                holder.clientName.setText(clientData.get("firstName").toString() + " " + clientData.get("lastName").toString());
            }
        });
    }

    @Override
    public int getItemCount() {
        return reviewList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView clientPic;
        TextView clientName;
        TextView reviewDate;
        TextView mealName;
        TextView rating;
        TextView reviewDescription;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            clientPic = (ImageView) itemView.findViewById(R.id.iv_clientReviewProfilePic);
            clientName = (TextView) itemView.findViewById(R.id.tv_clientReviewName);
            reviewDate = (TextView) itemView.findViewById(R.id.tv_clientReviewDate);
            mealName = (TextView) itemView.findViewById(R.id.tv_clientReviewMealName);
            rating = (TextView) itemView.findViewById(R.id.tv_clientReviewRating);
            reviewDescription = (TextView) itemView.findViewById(R.id.tv_clientReviewDescription);
        }
    }
}
