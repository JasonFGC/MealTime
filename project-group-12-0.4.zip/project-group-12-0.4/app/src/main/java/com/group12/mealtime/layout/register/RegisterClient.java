package com.group12.mealtime.layout.register;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Account;
import com.group12.mealtime.data.Client;
import com.group12.mealtime.layout.client.ClientMain;
import com.group12.mealtime.utils.FormValidator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import static android.content.ContentValues.TAG;

public class RegisterClient extends AppCompatActivity {

    private boolean formIsValid;

    private boolean firstNameIsValid;
    private boolean lastNameIsValid;
    private boolean streetNumberIsValid;
    private boolean streetNameIsValid;
    private boolean cityIsValid;
    private boolean postalCodeIsValid;
    private boolean creditCardExpDateIsValid;
    private boolean creditCardNumberIsValid;
    private boolean cvvIsValid;

    private String id;
    private String email;
    private String pic;
    private EditText firstName;
    private EditText lastName;
    private EditText streetNumber;
    private EditText streetName;
    private EditText city;
    private EditText postalCode;
    private EditText creditCardNumber;
    private EditText creditCardExpDate;
    private EditText cvv;
    private ImageView registerButton;

    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registerclient);
        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        email = intent.getStringExtra("email");
        pic = intent.getStringExtra("pic");
        firstName = (EditText) findViewById(R.id.firstName);
        lastName = (EditText) findViewById(R.id.lastName);
        streetNumber = (EditText) findViewById(R.id.streetNumber);
        streetName = (EditText) findViewById(R.id.streetName);
        city = (EditText) findViewById(R.id.city);
        postalCode = (EditText) findViewById(R.id.postalCode);
        creditCardNumber = (EditText) findViewById(R.id.creditCardNum);
        creditCardExpDate = (EditText) findViewById(R.id.creditCardExpDate);
        registerButton = (ImageView) findViewById(R.id.registerButtonClient);
        cvv = (EditText) findViewById(R.id.cvv);
        db = FirebaseFirestore.getInstance();
        setupEventListeners();
    }

    private void setupEventListeners() {
        firstName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyFirstNameInput();
            }
        });

        lastName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyLastNameInput();
            }
        });

        streetNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyStreetNumberInput();
            }
        });

        streetName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyStreetNameInput();
            }
        });

        city.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyCityInput();
            }
        });

        postalCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyPostalCodeInput();
            }
        });

        creditCardNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyCreditCardNumberInput();
            }
        });

        creditCardExpDate.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyCreditCardExpDateInput();
            }
        });

        cvv.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyCvvInput();
            }
        });

        registerButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptRegister();
            }
        });
    }

    private void verifyFirstNameInput() {
        String firstNameText = firstName.getText().toString();
        // Verify length of input is < 20 and it does not contain any numbers [0-9]
        if (FormValidator.isInvalidName(firstNameText)) {
            firstName.setTextColor(Color.RED);
            this.firstNameIsValid = false;
        } else {
            this.firstNameIsValid = true;
            firstName.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyLastNameInput() {
        String lastNameText = lastName.getText().toString();
        // Verify length of input is < 20 and it does not contain any numbers [0-9]
        if (FormValidator.isInvalidName(lastNameText)) {
            lastName.setTextColor(Color.RED);
            this.lastNameIsValid = false;
        } else {
            this.lastNameIsValid = true;
            lastName.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyStreetNumberInput() {
        String streetNumberText = streetNumber.getText().toString();
        // Verify length of input is < 6 and it contains only numbers [0-9]
        if (FormValidator.isInvalidStreetNumber(streetNumberText)) {
            streetNumber.setTextColor(Color.RED);
            this.streetNumberIsValid = false;
        } else {
            this.streetNumberIsValid = true;
            streetNumber.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyStreetNameInput() {
        String streetNameText = streetName.getText().toString();
        // Verify input does not contain numbers [0-9]
        if (FormValidator.isInvalidStreetName(streetNameText)) {
            streetName.setTextColor(Color.RED);
            this.streetNameIsValid = false;
        } else {
            this.streetNameIsValid = true;
            streetName.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyCityInput() {
        String cityNameText = city.getText().toString();
        // Verify length of input is < 86 and does not contain numbers [0-9]
        if (FormValidator.isInvalidCity(cityNameText)) {
            city.setTextColor(Color.RED);
            this.cityIsValid = false;
        } else {
            this.cityIsValid = true;
            city.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyPostalCodeInput() {
        // Get postal code text and remove all whitespace
        String postalCodeText = postalCode.getText().toString().replaceAll("\\s+", "");
        // Verify length of input is < 7 and is a valid canadian postal code
        if (FormValidator.isInvalidPostalCode(postalCodeText)) {
            postalCode.setTextColor(Color.RED);
            this.postalCodeIsValid = false;
        } else {
            this.postalCodeIsValid = true;
            postalCode.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyCreditCardNumberInput() {
        String creditCardNumberText = creditCardNumber.getText().toString();
        // Verify length of input is < 17 and is as valid credit card number
        if (FormValidator.isInvalidCreditCardNumber(creditCardNumberText)) {
            creditCardNumber.setTextColor(Color.RED);
            this.creditCardNumberIsValid = false;
        } else {
            this.creditCardNumberIsValid = true;
            creditCardNumber.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyCreditCardExpDateInput() {
        String creditCardExpText = creditCardExpDate.getText().toString();
        // Verify length of input is < 5 and is a valid expiry date
        if (FormValidator.isInvalidCreditCardExpDate(creditCardExpText)) {
            creditCardExpDate.setTextColor(Color.RED);
            this.creditCardExpDateIsValid = false;
        } else {
            // Verify expiry date is in future
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/yy");
            simpleDateFormat.setLenient(false);
            try {
                Date expiryDate = simpleDateFormat.parse(creditCardExpText);
                boolean expired = expiryDate.before(new Date());
                if (expired) creditCardExpDate.setTextColor(Color.RED);
                else creditCardExpDate.setTextColor(Color.BLACK);
                this.creditCardExpDateIsValid = !expired;
            } catch (ParseException e) {
                Log.d("ERROR", e.getMessage());
            }

            creditCardExpDate.setTextColor(Color.BLACK);
            this.creditCardExpDateIsValid = true;
        }
        updateFormIsValid();
    }

    private void verifyCvvInput() {
        String cvvText = cvv.getText().toString();
        // Verify length of input is < 4 and is a valid cvv
        if (FormValidator.isInvalidCvv(cvvText)) {
            cvv.setTextColor(Color.RED);
            this.cvvIsValid = false;
        } else {
            this.cvvIsValid = true;
            cvv.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void attemptRegister() {
        Log.d("INFO","ATEMPT REG");
        verifyFirstNameInput();
        verifyLastNameInput();
        verifyStreetNumberInput();
        verifyStreetNameInput();
        verifyCityInput();
        verifyPostalCodeInput();
        verifyCreditCardNumberInput();
        verifyCreditCardExpDateInput();
        if(!firstNameIsValid){
            Log.d("FALSE","fname");
        }
        if(!lastNameIsValid){
            Log.d("FALSE","lname");
        }
        if(!streetNumberIsValid){
            Log.d("FALSE","snum");
        }
        if(!streetNameIsValid){
            Log.d("FALSE","sname");
        }
        if(!cityIsValid){
            Log.d("FALSE","cname");
        }
        if(!postalCodeIsValid){
            Log.d("FALSE","pcname");
        }
        if(!creditCardNumberIsValid){
            Log.d("FALSE","ccnum");
        }
        if(!creditCardExpDateIsValid){
            Log.d("FALSE","cexp");
        }
        if (formIsValid) {
            Log.d("INFO","Valid");
            HashMap<String, String> creditCardInfo = new HashMap<String, String>();
            creditCardInfo.put("number", creditCardNumber.getText().toString());
            creditCardInfo.put("exp", creditCardExpDate.getText().toString());
            creditCardInfo.put("cvv", cvv.getText().toString());

            HashMap<String, String> address = new HashMap<String, String>();
            address.put("city", city.getText().toString());
            address.put("country", "Canada");
            address.put("number", streetNumber.getText().toString());
            address.put("postalCode", postalCode.getText().toString());
            address.put("province", "ON");
            address.put("street", streetName.getText().toString());


            Account account = new Account(id,email,"CLIENT",address,creditCardInfo);
            Client client = new Client(id,firstName.getText().toString(),lastName.getText().toString(),pic);

            db.collection("Accounts").document(id).set(account)
                    .addOnSuccessListener(
                            new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "DocumentSnapshot successfully written!");
                                    db.collection("Clients").document(id).set(client)
                                            .addOnSuccessListener(
                                                    new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            Intent intent = new Intent(RegisterClient.this, ClientMain.class);
                                                            intent.putExtra("accountType", "CLIENT");
                                                            intent.putExtra("id", id);
                                                            RegisterClient.this.startActivity(intent);
                                                        }
                                                    })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Log.w(TAG, "Error writing document", e);
                                                }
                                            }
                                    );
                                }
                            })
                    .addOnFailureListener(new OnFailureListener() {
                                              @Override
                                              public void onFailure(@NonNull Exception e) {
                                                  Log.w(TAG, "Error writing document", e);
                                              }
                                          }
                    );
        }
    }

    private void updateFormIsValid() {
        this.formIsValid = (
                firstNameIsValid && lastNameIsValid && streetNumberIsValid && streetNameIsValid &&
                        cityIsValid && postalCodeIsValid && creditCardExpDateIsValid && creditCardNumberIsValid
        );
    }
}