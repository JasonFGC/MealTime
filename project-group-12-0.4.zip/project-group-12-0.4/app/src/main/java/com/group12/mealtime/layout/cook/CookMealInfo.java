package com.group12.mealtime.layout.cook;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Meal;
import com.group12.mealtime.utils.FormValidator;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class CookMealInfo extends AppCompatActivity {

    private EditText mealName;
    private EditText mealType;
    private EditText mealCuisine;
    private EditText mealPrice;
    private EditText mealDescription;
    private ImageView mealPicture;
    private ImageView editBtn;
    private ImageView trashBtn;
    private ImageView addIngredientBtn;
    private ImageView addallergenBtn;
    private Switch offeredSwitch;
    private ImageView offeredImage;
    String mealId;
    Boolean isOn = true;
    Boolean canChangepic = false;
    ListenerRegistration mealsListen;

    private boolean editMode = false;

    private Meal meal;
    
    List<String> ingredients;
    List<String> allergens;

    private RecyclerView ingredientRecyclerView;
    private RecyclerView.Adapter ingredientAdapter;
    private RecyclerView.LayoutManager ingredientLayoutManager;

    private RecyclerView allergenRecyclerView;
    private RecyclerView.Adapter allergenAdapter;
    private RecyclerView.LayoutManager allergenLayoutManager;

    DocumentReference mealDoc;

    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private StorageReference storageRef;

    private void enableEditText(EditText editText) {
        editText.setFocusableInTouchMode(true);
        editText.setEnabled(true);
        editText.setBackgroundResource(android.R.drawable.edit_text);
        editText.setCursorVisible(true);
    }

    private void enableEdit(){
        enableEditText(mealName);
        enableEditText(mealType);
        enableEditText(mealCuisine);
        enableEditText(mealPrice);
        enableEditText(mealDescription);
        offeredSwitch.setEnabled(true);
        addallergenBtn.setVisibility(View.VISIBLE);
        addIngredientBtn.setVisibility(View.VISIBLE);
        canChangepic = true;

        ingredientAdapter = new MealListRecyclerViewAdapter(ingredients, CookMealInfo.this, editMode, mealId,0);
        allergenAdapter = new MealListRecyclerViewAdapter(allergens, CookMealInfo.this , editMode, mealId,1);
        ingredientRecyclerView.setAdapter(ingredientAdapter);
        allergenRecyclerView.setAdapter(allergenAdapter);

    }
    private void disableEditText(EditText editText) {
        editText.setFocusable(false);
        editText.setEnabled(false);
        editText.setCursorVisible(false);
        editText.setBackgroundColor(Color.TRANSPARENT);
        editText.setTextColor(Color.rgb(0,0,0));
    }
    
    private void disableEdit(boolean setAdaptor){
        disableEditText(mealName);
        disableEditText(mealType);
        disableEditText(mealCuisine);
        disableEditText(mealPrice);
        disableEditText(mealDescription);
        offeredSwitch.setEnabled(false);
        addallergenBtn.setVisibility(View.GONE);
        addIngredientBtn.setVisibility(View.GONE);
        canChangepic = false;

        if(setAdaptor){
            ingredientAdapter = new MealListRecyclerViewAdapter(ingredients, CookMealInfo.this, editMode, mealId,0);
            allergenAdapter = new MealListRecyclerViewAdapter(allergens, CookMealInfo.this , editMode, mealId,1);
            ingredientRecyclerView.setAdapter(ingredientAdapter);
            allergenRecyclerView.setAdapter(allergenAdapter);
        }

    }

    private void saveInfo(){
        disableEdit(true);
        if(offeredSwitch.isChecked()){
            offeredImage.setVisibility(View.VISIBLE);
        }else{
            offeredImage.setVisibility(View.INVISIBLE);
        }
        mealDoc.update(
                "mealName",mealName.getText().toString(),
                "offered",offeredSwitch.isChecked(),
                "mealType",mealType.getText().toString(),
                "cuisineType",mealCuisine.getText().toString(),
                "price",Double.valueOf(mealPrice.getText().toString()),
                "description",mealDescription.getText().toString()
        );
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if(requestCode == 10) {
                Uri mealUri = data.getData();
                Uri mealFile = Uri.fromFile(new File(mealUri.getPath()));

                StorageReference mealRef = storageRef.child("meals/"+mealFile.getLastPathSegment());
                UploadTask mealPicUpload = mealRef.putFile(mealFile);

                mealPicUpload.addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                    }
                });


                Task<Uri> getDownloadUriTask = mealPicUpload.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if (!task.isSuccessful()) {
                            throw task.getException();
                        }

                        return mealRef.getDownloadUrl();
                    }
                });

                getDownloadUriTask.addOnCompleteListener(CookMealInfo.this, new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful()){
                            Uri mealFireUri = task.getResult();

                            if(!meal.getPic().equals(getString(R.string.defualt_meal_src))){
                                StorageReference oldMealPicRef = storage.getReferenceFromUrl(meal.getPic());
                                oldMealPicRef.delete();
                            }


                            mealDoc.update(
                                    "pic",mealFireUri.toString()
                            );
                        }
                    }
                });

            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cook_meal_info);



        mealId = getIntent().getStringExtra("mealId");
        Log.d("MEAL_ID2", mealId);

        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageRef = storage.getReference();
        mealDoc = db.collection("Meals").document(mealId);
        mealName = findViewById(R.id.et_mealName);
        mealType = findViewById(R.id.et_mealType);
        mealCuisine = findViewById(R.id.et_cuisineType);
        mealPrice = findViewById(R.id.et_price);
        mealDescription = findViewById(R.id.et_description);
        mealPicture = findViewById(R.id.iv_mealPicture);
        editBtn = findViewById(R.id.iv_edit);
        trashBtn = findViewById(R.id.iv_delete);
        offeredSwitch = findViewById(R.id.sw_edit_offered);
        offeredImage = findViewById(R.id.iv_offered);
        addallergenBtn = findViewById(R.id.iv_addAllergenBtn);
        addIngredientBtn = findViewById(R.id.iv_addIngredientBtn);


        mealPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(canChangepic){
                    ImagePicker.with(CookMealInfo.this).cropSquare().compress(256).maxResultSize(100,100).start(10);
                }
            }
        });

        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(editMode) {
                    if(isValid()) {
                        editBtn.setImageResource(R.drawable.editicon);
                        editMode = false;
                        saveInfo();
                    }
                } else {
                    editBtn.setImageResource(R.drawable.saveicon);
                    editMode = true;
                    enableEdit();
                }
            }
        });

        trashBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(offeredSwitch.isChecked()){
                    Toast.makeText(getApplicationContext(),"Can't Delete An Offered Meal", Toast.LENGTH_SHORT).show();
                } else{
                    mealsListen.remove();
                    isOn = false;
                    finish();
                    if(!meal.getPic().equals(getString(R.string.defualt_meal_src))){
                        StorageReference oldMealPicRef = storage.getReferenceFromUrl(meal.getPic());
                        oldMealPicRef.delete();
                    }
                    mealDoc.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            isOn = false;
                            return;
                        }
                    });
                }
            }
        });
    }

    private boolean isValid() {
        boolean b1 = mealNameIsValid();
        boolean b2 = mealTypeIsValid();
        boolean b3 = cuisineTypeIsValid();
        boolean b4 = mealPriceIsValid();
        boolean b5 = mealDescriptionIsValid();
        return b1 && b2 && b3 && b4 && b5;
    }

    private boolean mealNameIsValid() {
        if(FormValidator.isInvalidMealName(mealName.getText().toString())) {
            mealName.setTextColor(Color.RED);
            return false;
        }
        return true;
    }

    private boolean mealTypeIsValid() {
        if(FormValidator.isInvalidMealType(mealType.getText().toString())) {
            mealType.setTextColor(Color.RED);
            return false;
        }
        return true;
    }

    private boolean cuisineTypeIsValid() {
        if(FormValidator.isInvalidCuisineType(mealCuisine.getText().toString())) {
            mealCuisine.setTextColor(Color.RED);
            return false;
        }
        return true;
    }

    private boolean mealPriceIsValid() {
        if(FormValidator.isInvalidMealPrice(mealPrice.getText().toString())) {
            mealPrice.setTextColor(Color.RED);
            return false;
        }
        return true;
    }

    private boolean mealDescriptionIsValid() {
        if(FormValidator.isInvalidMealDescription(mealDescription.getText().toString())) {
            mealDescription.setTextColor(Color.RED);
            return false;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        mealsListen.remove();
        isOn = false;
    }

    @Override
    protected void onStart() {
        super.onStart();
        disableEdit(false);


        ingredientRecyclerView = (RecyclerView) findViewById(R.id.rv_ingredients);
        ingredientRecyclerView.setNestedScrollingEnabled(false);

        ingredients = new ArrayList<String>();
        ingredientAdapter = new MealListRecyclerViewAdapter(ingredients, CookMealInfo.this, editMode, mealId,0);
        ingredientRecyclerView.setAdapter(ingredientAdapter);

        ingredientLayoutManager = new LinearLayoutManager(this);
        ingredientRecyclerView.setLayoutManager(ingredientLayoutManager);

        allergenRecyclerView = (RecyclerView) findViewById(R.id.rv_allergens);
        allergenRecyclerView.setNestedScrollingEnabled(false);

        allergens = new ArrayList<String>();
        allergenAdapter = new MealListRecyclerViewAdapter(allergens, CookMealInfo.this , editMode, mealId,1);
        allergenRecyclerView.setAdapter(allergenAdapter);

        allergenLayoutManager = new LinearLayoutManager(this);
        allergenRecyclerView.setLayoutManager(allergenLayoutManager);



        mealsListen = mealDoc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot doc, @Nullable FirebaseFirestoreException error) {
                if (isOn) {
                    meal = new Meal(doc.getId().toString(), doc.get("cuisineType").toString(), doc.get("description").toString(), doc.get("mealName").toString(), doc.get("mealType").toString(), (Boolean) doc.get("offered"), doc.get("pic").toString(), (Double) doc.get("price"));
                    mealName.setText(meal.getMealName());
                    mealType.setText(meal.getMealType());
                    mealCuisine.setText(meal.getCuisineType());
                    mealPrice.setText(String.valueOf(meal.getPrice()));
                    mealDescription.setText(meal.getDescription());
                    if (meal.isOffered()) {
                        offeredImage.setVisibility(View.VISIBLE);
                        offeredSwitch.setChecked(true);
                    } else {
                        offeredImage.setVisibility(View.INVISIBLE);
                        offeredSwitch.setChecked(false);
                    }

                    Picasso.get().load(meal.getPic()).resize(100, 100).centerCrop().into(mealPicture);


                    ingredients = (List<String>) doc.get("ingredients");
                  }
                    allergens = (List<String>) doc.get("allergens");


                    ingredientAdapter = new MealListRecyclerViewAdapter(ingredients, CookMealInfo.this, editMode, mealId, 0);
                    allergenAdapter = new MealListRecyclerViewAdapter(allergens, CookMealInfo.this, editMode, mealId, 1);
                    ingredientRecyclerView.setAdapter(ingredientAdapter);
                    allergenRecyclerView.setAdapter(allergenAdapter);
                }
            });

        addIngredientBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ingredients.add("");
                ingredientAdapter = new MealListRecyclerViewAdapter(ingredients, CookMealInfo.this, editMode, mealId,0);
                ingredientRecyclerView.setAdapter(ingredientAdapter);
            }
        });

        addallergenBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                allergens.add("");
                allergenAdapter = new MealListRecyclerViewAdapter(allergens, CookMealInfo.this, editMode, mealId,1);
                allergenRecyclerView.setAdapter(allergenAdapter);
            }
        });

        mealName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                mealName.setTextColor(Color.BLACK);
            }
        });
        mealCuisine.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                mealCuisine.setTextColor(Color.BLACK);
            }
        });
        mealType.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                mealType.setTextColor(Color.BLACK);
            }
        });
        mealPrice.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                mealPrice.setTextColor(Color.BLACK);
            }
        });
        mealDescription.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                mealDescription.setTextColor(Color.BLACK);
            }
        });

    }
}