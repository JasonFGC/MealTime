package com.group12.mealtime.layout.client;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.group12.mealtime.R;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ClientOrderDetailsMealListRecyclerAdapter extends RecyclerView.Adapter<ClientOrderDetailsMealListRecyclerAdapter.MyViewHolder> {

    private List<String> items;
    private Context context;

    public ClientOrderDetailsMealListRecyclerAdapter(List<String> items, Context context){
        this.items = items;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.client_order_details_meal_list_item, parent, false);

        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
//        holder.item.setPaintFlags(holder.item.getPaintFlags() & (~ Paint.UNDERLINE_TEXT_FLAG));
        holder.item.setText("\u2022 " + items.get(position));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView item;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            item = (TextView) itemView.findViewById(R.id.tv_clientOrderDetailsMealListItemName);
        }
    }
}
