package com.group12.mealtime.utils;

public class TimeTools {

    public static long toMinutes(long ms) {
        return (ms / 1000) / 60;
    }

}
