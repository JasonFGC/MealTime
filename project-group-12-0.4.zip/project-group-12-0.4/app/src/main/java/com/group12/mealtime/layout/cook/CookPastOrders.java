package com.group12.mealtime.layout.cook;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.data.PurchaseRequest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class CookPastOrders extends AppCompatActivity {

    List<PurchaseRequest> prList = new ArrayList<PurchaseRequest>();

    private RecyclerView prRecyclerView;
    private RecyclerView.Adapter prAdpater;
    private RecyclerView.LayoutManager prLayoutManager;

    private String cookId;

    private FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cook_past_orders);
    }

    @Override
    protected void onStart() {
        super.onStart();

        prRecyclerView = (RecyclerView) findViewById(R.id.rv_pastOrders);


        prAdpater = new CookPastRecyclerViewAdapter(prList,this);
        prRecyclerView.setAdapter(prAdpater);
        prLayoutManager = new LinearLayoutManager(this);
        prRecyclerView.setHasFixedSize(true);

        prRecyclerView.setLayoutManager(prLayoutManager);


        prRecyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(this, prRecyclerView ,new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {
                        // do whatever
                    }

                    @Override public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );

        db = FirebaseFirestore.getInstance();
        cookId = getIntent().getStringExtra("cookId");

        db.collection("PurchaseRequests")
                .whereEqualTo("cookId", cookId)
                .whereIn("state", Arrays.asList("cooked", "picked"))
                .addSnapshotListener(new EventListener<QuerySnapshot>() {

                    @Override
                    public void onEvent(@Nullable QuerySnapshot value,
                                        @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            Log.d("COMPAINTSs",e.toString());
                            return;
                        }

                        prList.clear();
                        for (QueryDocumentSnapshot doc : value) {
                            PurchaseRequest pr = new PurchaseRequest(doc.getId(), doc.getString("mealId"), doc.getString("clientId"), doc.getString("cookId"),(Timestamp) doc.get("pickupTime"),doc.getString("state"), (Timestamp) doc.get("orderDate"));
                                prList.add(pr);
                        }

                        prAdpater = new CookPastRecyclerViewAdapter(prList,CookPastOrders.this);

                        prRecyclerView.setAdapter(prAdpater);
                    }
                });
    }
}