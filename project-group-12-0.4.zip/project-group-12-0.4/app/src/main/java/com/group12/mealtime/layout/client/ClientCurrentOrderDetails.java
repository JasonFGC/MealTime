package com.group12.mealtime.layout.client;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Complaint;
import com.group12.mealtime.layout.cook.CookMealInfo;
import com.group12.mealtime.layout.cook.MealListRecyclerViewAdapter;
import com.group12.mealtime.utils.TimeTools;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ClientCurrentOrderDetails extends AppCompatActivity {

    private String prId;
    private String cookId;
    private String clientId;
    private FirebaseFirestore db;

    private TextView mealName;
    private ImageView mealPic;
    private TextView cookName;
    private TextView status;
    private TextView mealPrice;
    private TextView orderDate;
    private TextView pickupTime;
    private TextView mealType;
    private TextView cuisineType;
    private TextView mealDescription;
    private ImageView reviewCookButton;
    private ImageView complaintButton;

    private RecyclerView ingredientRecyclerView;
    private RecyclerView.Adapter ingredientAdapter;
    private RecyclerView.LayoutManager ingredientLayoutManager;

    private List<String> ingredients = new ArrayList<String>();

    private RecyclerView allergenRecyclerView;
    private RecyclerView.Adapter allergenAdapter;
    private RecyclerView.LayoutManager allergenLayoutManager;

    private List<String> allergens = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_current_order_details);

        prId = getIntent().getStringExtra("id");
        cookId = getIntent().getStringExtra("cookId");
        clientId = getIntent().getStringExtra("clientId");

        db = FirebaseFirestore.getInstance();

        mealName = (TextView) findViewById(R.id.tv_clientCurrentOrderDetailsMealName);
        mealPic = (ImageView) findViewById(R.id.iv_clientCurrentOrderDetailsMealPic);
        cookName = (TextView) findViewById(R.id.tv_clientCurrentOrderDetailsCookName);
        status = (TextView) findViewById(R.id.tv_clientCurrentOrderDetailsStatus);
        mealPrice = (TextView) findViewById(R.id.tv_clientCurrentOrderDetailsMealPrice);
        orderDate = (TextView) findViewById(R.id.tv_clientCurrentOrderDetailsOrderDate);
        pickupTime = (TextView) findViewById(R.id.tv_clientCurrentOrderDetailsPickupTime);
        mealType = (TextView) findViewById(R.id.tv_clientCurrentOrderDetailsMealType);
        cuisineType = (TextView) findViewById(R.id.tv_clientCurrentOrderDetailsCuisineType);
        mealDescription = (TextView) findViewById(R.id.tv_clientCurrentOrderDetailsDescription);
        reviewCookButton = (ImageView) findViewById(R.id.btn_reviewCookBtn);
        complaintButton = (ImageView) findViewById(R.id.btn_complaintBtn);

        reviewCookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent reviewIntent = new Intent(ClientCurrentOrderDetails.this, ClientReview.class);
                reviewIntent.putExtra("id", prId);
                startActivity(reviewIntent);
            }
        });

        complaintButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent complaintIntent = new Intent(ClientCurrentOrderDetails.this, ClientComplaint.class);
                complaintIntent.putExtra("id", prId);
                startActivity(complaintIntent);
            }
        });

        ingredientRecyclerView = (RecyclerView) findViewById(R.id.rv_clientCurrentOrderDetailsIngredients);
        ingredientRecyclerView.setNestedScrollingEnabled(false);

        ingredients = new ArrayList<String>();
        ingredientAdapter = new ClientOrderDetailsMealListRecyclerAdapter(ingredients, ClientCurrentOrderDetails.this);
        ingredientRecyclerView.setAdapter(ingredientAdapter);

        ingredientLayoutManager = new LinearLayoutManager(this);
        ingredientRecyclerView.setLayoutManager(ingredientLayoutManager);

        allergenRecyclerView = (RecyclerView) findViewById(R.id.rv_clientCurrentOrderDetailsAllergens);
        allergenRecyclerView.setNestedScrollingEnabled(false);

        allergens = new ArrayList<String>();
        allergenAdapter = new ClientOrderDetailsMealListRecyclerAdapter(allergens, ClientCurrentOrderDetails.this);
        allergenRecyclerView.setAdapter(allergenAdapter);

        allergenLayoutManager = new LinearLayoutManager(this);
        allergenRecyclerView.setLayoutManager(allergenLayoutManager);

        DocumentReference prDoc = db.collection("PurchaseRequests").document(prId);
        prDoc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot doc, @Nullable FirebaseFirestoreException error) {
                DocumentReference cookDoc = db.collection("Cooks").document(doc.get("cookId").toString());
                cookDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        DocumentSnapshot cookData = task.getResult();
                        cookName.setText(cookData.get("firstName").toString() + " " + cookData.get("lastName").toString());
                    }
                });
                DocumentReference mealDoc = db.collection("Meals").document(doc.get("mealId").toString());
                mealDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        DocumentSnapshot mealData = task.getResult();
                        mealName.setText(mealData.get("mealName").toString());
                        Picasso.get().load(mealData.get("pic").toString()).resize(100, 100).centerCrop().into(mealPic);
                        mealPrice.setText("$" + mealData.get("price").toString());
                        mealType.setText(mealData.get("mealType").toString());
                        cuisineType.setText(mealData.get("cuisineType").toString());
                        mealDescription.setText(mealData.get("description").toString());
                        ingredients = (List<String>) mealData.get("ingredients");
                        allergens = (List<String>) mealData.get("allergens");
                        ingredientAdapter = new ClientOrderDetailsMealListRecyclerAdapter(ingredients, ClientCurrentOrderDetails.this);
                        ingredientRecyclerView.setAdapter(ingredientAdapter);
                        allergenAdapter = new ClientOrderDetailsMealListRecyclerAdapter(allergens, ClientCurrentOrderDetails.this);
                        allergenRecyclerView.setAdapter(allergenAdapter);
                    }
                });
                String statusText = doc.get("state").toString();
                if(statusText.equals("cooked")) {
                    status.setText("Cooked (ready for pickup)");
                    status.setTextColor(Color.rgb(0, 214, 143));
                } else if (statusText.equals("approved")) {
                    status.setText("Approved");
                    status.setTextColor(Color.rgb(214, 154, 0));
                }

                Calendar orderDate = Calendar.getInstance();
                orderDate.setTime(((Timestamp) doc.get("orderDate")).toDate());
                int month = orderDate.get(Calendar.MONTH) + 1;
                int day = orderDate.get(Calendar.DAY_OF_MONTH);
                int year = orderDate.get(Calendar.YEAR);
                String dateString = (
                        String.format("%02d", month) +
                                " / " + String.format("%02d", day) + " / " +
                                year
                );
                ClientCurrentOrderDetails.this.orderDate.setText(dateString);
                Calendar pickupDate = Calendar.getInstance();
                pickupDate.setTime(((Timestamp) doc.get("pickupTime")).toDate());
                long currentTime = Calendar.getInstance().getTimeInMillis();
                long pickupTime = pickupDate.getTimeInMillis();
                long minutes = TimeTools.toMinutes(pickupTime - currentTime);
                if(minutes <= 0) {
                    ClientCurrentOrderDetails.this.pickupTime.setText((minutes * -1) + " min late");
                    ClientCurrentOrderDetails.this.pickupTime.setTextColor(Color.RED);
                } else {
                    ClientCurrentOrderDetails.this.pickupTime.setText(minutes + " min");
                }
            }
        });
    }
}