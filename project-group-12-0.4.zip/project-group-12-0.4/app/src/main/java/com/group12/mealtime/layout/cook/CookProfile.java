package com.group12.mealtime.layout.cook;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.auth0.android.Auth0;
import com.auth0.android.authentication.AuthenticationException;
import com.auth0.android.callback.Callback;
import com.auth0.android.provider.WebAuthProvider;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Account;
import com.group12.mealtime.data.Cook;
import com.group12.mealtime.layout.login.Login;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.HashMap;

public class CookProfile extends AppCompatActivity {

    private Auth0 account;
    String cookId;

    Cook cook;
    Account acook;
    private FirebaseFirestore db;

    ImageView cookImg;
    TextView Name;
    TextView Address;
    TextView Desc;
    TextView Email;
    TextView Rating;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_cook_profile);
    }

    @Override
    protected void onStart() {
        super.onStart();

        cookImg = findViewById(R.id.iv_cookPic);
        Name = findViewById(R.id.tv_pname);
        Address = findViewById(R.id.tv_paddress);
        Desc = findViewById(R.id.tv_pdesc);
        Email = findViewById(R.id.tv_pemail);
        Rating = findViewById(R.id.tv_prating);

        db = FirebaseFirestore.getInstance();

        cookId = getIntent().getStringExtra("cookId");
        Log.d("TESTBLAH",cookId);
        DocumentReference cookRef = db.collection("Cooks").document(cookId);
        cookRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot doc = task.getResult();
                    if (doc.exists()) {

                        cook = new Cook(doc.getId(), doc.getString("firstName"), doc.getString("lastName"), doc.getString("description"), (HashMap<String, String>) doc.get("address"),Integer.valueOf(doc.get("mealsSold").toString()) , Integer.valueOf(doc.get("numReviews").toString()) , doc.getString("pic"), Double.valueOf(doc.get("rating").toString()) , (Timestamp) doc.get("releaseDate"), (boolean) doc.get("suspended"));

                        Picasso.get().load(cook.getPic()).resize(150, 150).centerCrop().into(cookImg);
                        Name.setText(cook.getFirstName() + " " + cook.getLastName());

                        String addressString =
                                cook.getAddress().get("number") + " "
                                + cook.getAddress().get("street") + ", "
                                        + cook.getAddress().get("city") + ", "
                                        + cook.getAddress().get("province") + ", "
                                        + cook.getAddress().get("country") + ", "
                                        + cook.getAddress().get("postalCode");

                        Address.setText(addressString);
                        Desc.setText(cook.getDescription());
                        Rating.setText(String.valueOf(cook.getRating()));
                    }
                }
            }
        });

        DocumentReference accountRef = db.collection("Accounts").document(cookId);
        accountRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot doc = task.getResult();
                    if (doc.exists()) {
                        acook = new Account(doc.getId(),doc.getString("email"),"COOK");
                        Email.setText(acook.getEmail());
                    }
                }
            }
        });



        ImageView pastOrderBtn = findViewById(R.id.btn_pastorders);

        pastOrderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pastorderIntent = new Intent(CookProfile.this,CookPastOrders.class);
                pastorderIntent.putExtra("cookId",cookId);
                startActivity(pastorderIntent);
            }
        });



        account = new Auth0(getString(R.string.com_auth0_client_id), getString(R.string.com_auth0_domain));
        ImageView logout = findViewById(R.id.btn_logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Declare the callback that will receive the result
                Callback<Void, AuthenticationException> logoutCallback = new Callback<Void, AuthenticationException>() {
                    @Override
                    public void onFailure(@NonNull AuthenticationException e) {

                    }

                    @Override
                    public void onSuccess(@Nullable Void payload) {
                        //succeeded!
                        Log.d("INFO", "Logged Out");
                        startActivity(new Intent(CookProfile.this, Login.class));

                    }
                };

                WebAuthProvider.logout(account)
                        .withScheme("demo")
                        .start(CookProfile.this, logoutCallback);

                //Configure and launch the log out
            }
        });
    }
}