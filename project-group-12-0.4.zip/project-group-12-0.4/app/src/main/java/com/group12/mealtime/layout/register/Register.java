package com.group12.mealtime.layout.register;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.auth0.android.Auth0;
import com.auth0.android.authentication.AuthenticationException;
import com.auth0.android.callback.Callback;
import com.auth0.android.provider.WebAuthProvider;
import com.group12.mealtime.R;
import com.group12.mealtime.layout.login.Login;

public class Register extends AppCompatActivity {

    Button cookbtn;
    Button clientbtn;

    String accountId;
    String accountEmail;
    String pic;

    private Auth0 account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        account = new Auth0(getString(R.string.com_auth0_client_id), getString(R.string.com_auth0_domain));
        setContentView(R.layout.activity_register);
        cookbtn = (Button) findViewById(R.id.cookBtn);
        clientbtn = (Button) findViewById(R.id.clientBtn);

        Intent intent = getIntent();
        accountId = intent.getStringExtra("id");
        accountEmail = intent.getStringExtra("email");
        pic = intent.getStringExtra("pic");


        Button cookbtn = (Button) findViewById(R.id.cookBtn);
        cookbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                regCook();
            }
        });
        Button button = (Button) findViewById(R.id.clientBtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                regClient();
            }
        });
    }

    public void regCook(){

        Intent myIntentCook = new Intent(Register.this, RegisterCook.class);
        myIntentCook.putExtra("id", accountId);
        myIntentCook.putExtra("email", accountEmail);
        myIntentCook.putExtra("pic",pic);
        Register.this.startActivity(myIntentCook);
    }

    public void regClient(){
        Intent myIntentClient = new Intent(Register.this, RegisterClient.class);
        myIntentClient.putExtra("id", accountId);
        myIntentClient.putExtra("email", accountEmail);
        myIntentClient.putExtra("pic",pic);
        Register.this.startActivity(myIntentClient);
    }

    public void logout(View view){
        //Declare the callback that will receive the result
        Callback<Void, AuthenticationException> logoutCallback = new Callback<Void, AuthenticationException>() {
            @Override
            public void onFailure(@NonNull AuthenticationException e) {

            }

            @Override
            public void onSuccess(@Nullable Void payload) {
                //succeeded!
                Log.d("INFO", "Logged Out");
                Register.this.startActivity(new Intent(Register.this, Login.class));

            }
        };

        WebAuthProvider.logout(account)
                .withScheme("demo")
                .start(Register.this, logoutCallback);

        //Configure and launch the log out




    }
}