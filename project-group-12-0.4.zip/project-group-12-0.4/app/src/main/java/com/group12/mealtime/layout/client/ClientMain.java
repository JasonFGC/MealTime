package com.group12.mealtime.layout.client;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.databinding.ActivityClientMainBinding;
import com.squareup.picasso.Picasso;

public class ClientMain extends AppCompatActivity {

    private ActivityClientMainBinding binding;
    private String clientId;
    private ImageView profile;
    private FirebaseFirestore db;
    private String clientPic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        clientId = getIntent().getStringExtra("id");
        Log.d("CLIENT_ID", clientId);

        db = FirebaseFirestore.getInstance();

        binding = ActivityClientMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.bottomNavBarClient.setSelectedItemId(R.id.client_home);
        replaceClientFragment(new ClientHome());

        binding.bottomNavBarClient.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.client_orders:
                    replaceClientFragment(new ClientPendingOrders());
                    break;
                case R.id.client_home:
                    replaceClientFragment(new ClientHome());
                    break;
                case R.id.client_search:
                    replaceClientFragment(new ClientSearch());
                    break;
            }
            return true;
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        profile = (ImageView) findViewById(R.id.ProfileBtn);

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // go to client profile activity

                Intent profileIntent = new Intent(ClientMain.this,ClientProfile.class);
                profileIntent.putExtra("id",clientId);
                startActivity(profileIntent);
            }
        });
        DocumentReference adminRef = db.collection("Clients").document(clientId);
        adminRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        clientPic = document.get("picture").toString();

                        Picasso.get().load(clientPic).resize(32, 32).centerCrop().into(profile);
                    }
                }
            }
        });
    }

    private void replaceClientFragment(Fragment fragment) {
        Bundle bundle = new Bundle();
        bundle.putString("clientId", clientId);
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayoutClient,fragment);
        fragmentTransaction.commit();
    }
}