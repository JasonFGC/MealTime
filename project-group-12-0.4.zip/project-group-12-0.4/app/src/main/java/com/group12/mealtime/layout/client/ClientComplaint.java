package com.group12.mealtime.layout.client;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Complaint;
import com.group12.mealtime.databinding.ClientCurrentOrderCardBinding;
import com.group12.mealtime.utils.TimeTools;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.List;

public class ClientComplaint extends AppCompatActivity {

    private String prId;
    private FirebaseFirestore db;

    private ImageView mealPic;
    private TextView mealName;
    private TextView mealType;
    private TextView cuisineType;
    private TextView mealDescription;
    private TextView orderDate;
    private EditText complaint;
    private ImageView doneBtn;

    private boolean hasText = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_complaint);
        db = FirebaseFirestore.getInstance();
        prId = getIntent().getStringExtra("id");

        mealPic = (ImageView) findViewById(R.id.iv_clientComplaintMealPic);
        mealName = (TextView) findViewById(R.id.tv_clientComplaintMealName);
        mealType = (TextView) findViewById(R.id.tv_clientComplaintMealType);
        cuisineType = (TextView) findViewById(R.id.tv_clientComplaintCuisineType);
        mealDescription = (TextView) findViewById(R.id.tv_clientComplaintMealDescription);
        orderDate = (TextView) findViewById(R.id.tv_clientComplaintOrderDate);
        complaint = (EditText) findViewById(R.id.et_clientComplaint);
        complaint.setText("");
        doneBtn = (ImageView) findViewById(R.id.btn_doneComplaint);
        doneBtn.setImageAlpha(100);

        complaint.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(complaint.getText().length() == 0) {
                    hasText = false;
                    doneBtn.setImageAlpha(100);
                } else {
                    hasText = true;
                    doneBtn.setImageAlpha(255);
                }
            }
        });

        doneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!hasText) return;
                DocumentReference prDoc = db.collection("PurchaseRequests").document(prId);
                prDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        Complaint complaint = new Complaint();
                        complaint.setDescription(ClientComplaint.this.complaint.getText().toString());
                        complaint.setReleaseDate(null);
                        complaint.setState("pending");
                        DocumentSnapshot docRef = task.getResult();
                        DocumentReference clientDoc = db.collection("Clients").document(docRef.get("clientId").toString());
                        clientDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                DocumentSnapshot docRefClient = task.getResult();
                                complaint.setClientFirstName(docRefClient.get("firstName").toString());
                                complaint.setClientLastName(docRefClient.get("lastName").toString());
                                complaint.setClientPic(docRefClient.get("picture").toString());
                                DocumentReference cookDoc = db.collection("Cooks").document(docRef.get("cookId").toString());
                                cookDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                        DocumentSnapshot docRefCook = task.getResult();
                                        complaint.setCookFirstName(docRefCook.get("firstName").toString());
                                        complaint.setCookLastName(docRefCook.get("lastName").toString());
                                        complaint.setCookId(docRefCook.getId().toString());
                                        db.collection("Complaints").add(complaint).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                            @Override
                                            public void onSuccess(DocumentReference documentReference) {
                                                documentReference.update("id", documentReference.getId());
                                                Intent intent = new Intent(ClientComplaint.this, ClientCurrentOrderDetails.class);
                                                intent.putExtra("id", prId);
                                                startActivity(intent);
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });

        DocumentReference prDoc = db.collection("PurchaseRequests").document(prId);
        prDoc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot doc, @Nullable FirebaseFirestoreException error) {
                DocumentReference mealDoc = db.collection("Meals").document(doc.get("mealId").toString());
                mealDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        DocumentSnapshot mealData = task.getResult();
                        mealName.setText(mealData.get("mealName").toString());
                        Picasso.get().load(mealData.get("pic").toString()).resize(120, 120).centerCrop().into(mealPic);
                        mealType.setText(mealData.get("mealType").toString());
                        cuisineType.setText(mealData.get("cuisineType").toString());
                        mealDescription.setText(mealData.get("description").toString());
                    }
                });
                Calendar orderDate = Calendar.getInstance();
                orderDate.setTime(((Timestamp) doc.get("orderDate")).toDate());
                int month = orderDate.get(Calendar.MONTH) + 1;
                int day = orderDate.get(Calendar.DAY_OF_MONTH);
                int year = orderDate.get(Calendar.YEAR);
                String dateString = (
                        String.format("%02d", month) +
                                " / " + String.format("%02d", day) + " / " +
                                year
                );
                ClientComplaint.this.orderDate.setText(dateString);
            }
        });
    }
}