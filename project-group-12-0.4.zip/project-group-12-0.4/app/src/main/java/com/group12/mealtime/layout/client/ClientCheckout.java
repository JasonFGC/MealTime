package com.group12.mealtime.layout.client;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.data.PurchaseRequest;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class ClientCheckout extends AppCompatActivity {
    private String clientId;
    private String mealId;
    private FirebaseFirestore db;
    private TextView clientNameTV;
    private TextView clientEmailTV;
    private TextView creditCardInfoTV;
    private TextView foodPriceTV;
    private TextView taxAmountTV;
    private TextView totalAmountTV;
    private TextView cookAddressTV;
    private EditText pickupTimeSetET;
    private ImageView placeOrderIV;
    private double price;
    private double tax;
    private double total;
    private String cookID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_checkout);


        clientNameTV = (TextView) findViewById(R.id.client_name);
        clientEmailTV = (TextView) findViewById(R.id.client_email);
        creditCardInfoTV = (TextView) findViewById(R.id.creditcardinfo);
        foodPriceTV = (TextView) findViewById(R.id.priceoffood);
        taxAmountTV = (TextView) findViewById(R.id.taxoffood);
        totalAmountTV = (TextView) findViewById(R.id.totaloffood);
        cookAddressTV = (TextView) findViewById(R.id.cookAddress);
        pickupTimeSetET= (EditText) findViewById(R.id.ordertime);
        placeOrderIV = (ImageView)  findViewById(R.id.iv_place_order);

        placeOrderIV.requestFocus();


        mealId = getIntent().getStringExtra("mealId");
        clientId = getIntent().getStringExtra("clientId");

        db = FirebaseFirestore.getInstance();

        DocumentReference mealDoc = db.collection("Meals").document(mealId);
        DocumentReference clientDoc = db.collection("Clients").document(clientId);
        DocumentReference accountDoc = db.collection("Accounts").document(clientId);
        clientDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    DocumentSnapshot clientData = task.getResult();
                    clientNameTV.setText(clientData.getString("firstName")+" "+clientData.getString("lastName"));

                }
            }
        });

        accountDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    DocumentSnapshot accountData = task.getResult();
                    HashMap<String,String> creditCard = (HashMap<String, String>) accountData.get("creditCard");
                    String last4Digits = creditCard.get("number");
                    creditCardInfoTV.setText("**** **** **** "+last4Digits.substring(12));
                    clientEmailTV.setText(accountData.getString("email"));
                }
            }
        });

        mealDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()){
                    DocumentSnapshot mealData = task.getResult();
                    if(mealData.exists()){
                        price = mealData.getDouble("price");
                        price = Math.round(price * 100.0) / 100.0;
                        foodPriceTV.setText(Double.toString(price));

                        tax = price*0.13;
                        tax = Math.round(tax * 100.0) / 100.0;
                        taxAmountTV.setText(Double.toString(tax));

                        total = price + tax;
                        total = Math.round(total * 100.0) / 100.0;
                        totalAmountTV.setText(Double.toString(total));

                        DocumentReference cookRef = db.collection("Cooks").document(mealData.getString("cookId"));
                        cookRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task2) {
                                if (task2.isSuccessful()){
                                    DocumentSnapshot cookData = task2.getResult();
                                    if(cookData.exists()){
                                        cookID = cookData.getId();
                                        HashMap<String,String> address = (HashMap<String, String>) cookData.get("address");
                                        String addressString =
                                                address.get("number") + " "
                                                        + address.get("street") + ", "
                                                        + address.get("city") + ", "
                                                        + address.get("province") + ", "
                                                        + address.get("country") + ", "
                                                        + address.get("postalCode");

                                        cookAddressTV.setText(addressString);
                                    }
                                }
                            }
                        });
                    }
                }
            }
        });



        placeOrderIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Timestamp currentTime = new Timestamp(Calendar.getInstance().getTime());
                String addedTimeStr = pickupTimeSetET.getText().toString();
                long pickup;
                try{
                    pickup = Long.parseLong(addedTimeStr);

                    if (pickup < 0){
                        pickup = 0;
                    }
                } catch (Exception e){
                    pickup = 0;
                }


                if(pickup != 0){
                    pickup = pickup*60*1000;
                    pickup = pickup + (currentTime.getSeconds()*1000);
                    Timestamp pickupTime = new Timestamp(new Date(pickup));
                    PurchaseRequest pr = new PurchaseRequest("",mealId,clientId,cookID,pickupTime,"pending",currentTime);



                    db.collection("PurchaseRequests").add(pr).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            Intent HomeIntent = new Intent(ClientCheckout.this, ClientMain.class);
                            HomeIntent.putExtra("id",clientId);
                            finish();
                            startActivity(HomeIntent);


                        }
                    });
                } else{
                    Toast.makeText(ClientCheckout.this, "Please Enter Pickup Time", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

}