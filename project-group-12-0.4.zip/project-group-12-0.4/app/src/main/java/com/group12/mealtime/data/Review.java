package com.group12.mealtime.data;


import com.google.firebase.Timestamp;

public class Review {
    private String id;
    private boolean calculated;
    private String clientId;
    private String cookId;
    private Timestamp date;
    private String description;
    private String mealId;
    private float rating;


    public Review(){};

    public Review(String id, boolean calculated, String clientId, String cookId, Timestamp date, String description, String mealId, float rating) {
        this.id = id;
        this.calculated = calculated;
        this.clientId = clientId;
        this.cookId = cookId;
        this.date = date;
        this.description = description;
        this.mealId = mealId;
        this.rating = rating;
    }

    public String getId() {
        return id;
    }

    public boolean isCalculated() {
        return calculated;
    }

    public String getClientId() {
        return clientId;
    }

    public String getCookId() {
        return cookId;
    }

    public Timestamp getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public String getMealId() {
        return mealId;
    }

    public float getRating() {
        return rating;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setCalculated(boolean calculated) {
        this.calculated = calculated;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public void setCookId(String cookId) {
        this.cookId = cookId;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setMealId(String mealId) {
        this.mealId = mealId;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }
}
