package com.group12.mealtime.layout.admin;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.group12.mealtime.R;
import com.group12.mealtime.data.Complaint;

import java.util.Calendar;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ProcessedComplaintRecyclerAdapter extends RecyclerView.Adapter<ProcessedComplaintRecyclerAdapter.MyViewHolder> {
    List<Complaint> complaintList;
    Context context;

    public ProcessedComplaintRecyclerAdapter(List<Complaint> complaintList, Context context) {
        this.complaintList = complaintList;
        this.context = context;
    }

    @NonNull
    @Override
    public ProcessedComplaintRecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.complaint_processed_card, parent, false);

        ProcessedComplaintRecyclerAdapter.MyViewHolder holder = new ProcessedComplaintRecyclerAdapter.MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Complaint complaint = complaintList.get(position);
        holder.cookName.setText("Cook Name: " + complaint.getCookFirstName() + " " + complaint.getCookLastName());
        holder.cookId.setText(complaint.getCookId());
        holder.complaintDescription.setText(complaint.getDescription());
        if(complaint.getState().equals("dismissed")) {
            holder.processedStatus.setText("Complaint Dismissed");
            holder.status.setBackgroundColor(Color.rgb(0, 214, 143));
        } else if(complaint.getState().equals("suspended")) {
            if(complaint.getReleaseDate() == null) {
                holder.processedStatus.setText("Indefinite Ban");
                holder.status.setBackgroundColor(Color.rgb(214, 0, 0));
            } else {
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(complaint.getReleaseDate().toDate());
                int month = calendar.get(Calendar.MONTH) + 1;
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int year = calendar.get(Calendar.YEAR);
                String dateString = (
                        String.format("%02d", month) +
                                " / " + String.format("%02d", day) + " / " +
                                year
                );
                holder.processedStatus.setText("Banned Until " + dateString);
                holder.status.setBackgroundColor(Color.rgb(214, 154, 0));
            }
        }

    }

    @Override
    public int getItemCount() {
        return complaintList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView cookName;
        TextView processedStatus;
        TextView cookId;
        TextView complaintDescription;
        ImageView status;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cookName = (TextView) itemView.findViewById(R.id.tv_complaintProcessedCookName);
            processedStatus = (TextView) itemView.findViewById(R.id.tv_complaintProcessedStatus);
            cookId = (TextView) itemView.findViewById(R.id.tv_complaintProcessedCookId);
            complaintDescription = (TextView) itemView.findViewById(R.id.tv_complaintProcessedDescription);
            status = (ImageView) itemView.findViewById(R.id.iv_processedStatus);
        }
    }
}
