package com.group12.mealtime.layout.admin;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Complaint;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AdminInbox#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AdminInbox extends Fragment {

    private List<Complaint> complaintList = new ArrayList<Complaint>();

    private RecyclerView complaintRecyclerView;
    private RecyclerView.Adapter complaintAdapter;
    private RecyclerView.LayoutManager complaintLayoutManager;

    private FirebaseFirestore db;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AdminInbox() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AdminInbox.
     */
    // TODO: Rename and change types and number of parameters
    public static AdminInbox newInstance(String param1, String param2) {
        AdminInbox fragment = new AdminInbox();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        complaintRecyclerView = (RecyclerView) getView().findViewById(R.id.rv_complaints);

        complaintAdapter = new ComplaintRecyclerAdapter(complaintList, getActivity());
        complaintRecyclerView.setAdapter(complaintAdapter);
        complaintLayoutManager = new LinearLayoutManager(getActivity());
        complaintRecyclerView.setHasFixedSize(true);

        complaintRecyclerView.setLayoutManager(complaintLayoutManager);

        db = FirebaseFirestore.getInstance();

        db.collection("Complaints")
                .whereEqualTo("state", "pending")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            Log.d("COMPLAINTS",error.toString());
                            return;
                        }
                        complaintList.clear();
                        for(QueryDocumentSnapshot doc : value) {
                            Log.d("BRO", doc.getId().toString());
                            Log.d("BRO", doc.get("cookId").toString() );
                            Log.d("BRO", doc.get("cookFirstName").toString() );
                            Log.d("BRO", doc.get("cookLastName").toString() );
                            Log.d("BRO", doc.get("description").toString() );

                            if(doc.get("releaseDate") == null) {
                                Log.d("BRO", "null");
                            } else {
                                Log.d("BRO", ((Timestamp) doc.get("releaseDate")).toString());
                            }
                            Log.d("BRO", doc.get("clientFirstName").toString() );
                            Log.d("BRO", doc.get("clientLastName").toString() );
                            Log.d("BRO", doc.get("clientPic").toString() );
                            Complaint complaint = new Complaint(doc.get("cookId").toString(), doc.get("cookFirstName").toString(), doc.get("cookLastName").toString(), doc.get("description").toString(), doc.get("state").toString(), doc.getId().toString(), (Timestamp) doc.get("releaseDate"), doc.get("clientFirstName").toString(), doc.get("clientLastName").toString(), doc.get("clientPic").toString());
                            complaintList.add(complaint);
                        }
                        complaintAdapter = new ComplaintRecyclerAdapter(complaintList, getActivity());
                        complaintRecyclerView.setAdapter(complaintAdapter);
                    }
                });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_admin_inbox, container, false);
    }
}