package com.group12.mealtime.layout.client;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.data.PurchaseRequest;
import com.group12.mealtime.layout.cook.CookPastOrders;
import com.group12.mealtime.layout.cook.CookPastRecyclerViewAdapter;
import com.group12.mealtime.layout.cook.RecyclerItemClickListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ClientPastOrders extends AppCompatActivity {
    List<PurchaseRequest> prList = new ArrayList<PurchaseRequest>();

    private RecyclerView prRecyclerView;
    private RecyclerView.Adapter prAdpater;
    private RecyclerView.LayoutManager prLayoutManager;

    private String clientId;

    private FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_past_orders);
    }

    @Override
    protected void onStart() {
        super.onStart();

        prRecyclerView = (RecyclerView) findViewById(R.id.rv_cpastOrders);


        prAdpater = new PurchaseRequestRecyclerAdapter(prList,this);
        prRecyclerView.setAdapter(prAdpater);
        prLayoutManager = new LinearLayoutManager(this);
        prRecyclerView.setHasFixedSize(true);

        prRecyclerView.setLayoutManager(prLayoutManager);


        prRecyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(this, prRecyclerView ,new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {
                        // do whatever
                    }

                    @Override public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );

        db = FirebaseFirestore.getInstance();
        clientId = getIntent().getStringExtra("id");

        db.collection("PurchaseRequests")
                .whereEqualTo("clientId", clientId)
                .whereIn("state", Arrays.asList("rejected", "picked"))
                .addSnapshotListener(new EventListener<QuerySnapshot>() {

                    @Override
                    public void onEvent(@Nullable QuerySnapshot value,
                                        @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            Log.d("COMPAINTSs",e.toString());
                            return;
                        }

                        prList.clear();
                        for (QueryDocumentSnapshot doc : value) {
                            PurchaseRequest pr = new PurchaseRequest(doc.getId(), doc.getString("mealId"), doc.getString("clientId"), doc.getString("cookId"),(Timestamp) doc.get("pickupTime"),doc.getString("state"), (Timestamp) doc.get("orderDate"));
                            prList.add(pr);
                        }

                        prAdpater = new PurchaseRequestRecyclerAdapter(prList, ClientPastOrders.this);

                        prRecyclerView.setAdapter(prAdpater);
                    }
                });
    }
}