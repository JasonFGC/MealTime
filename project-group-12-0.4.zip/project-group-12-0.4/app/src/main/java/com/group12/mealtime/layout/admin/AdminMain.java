package com.group12.mealtime.layout.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.databinding.ActivityAdminMainBinding;
import com.squareup.picasso.Picasso;

import java.util.Calendar;

public class AdminMain extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    ActivityAdminMainBinding binding;
    private String adminId;
    ImageView profile;
    private FirebaseFirestore db;
    String adminPic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        adminId = getIntent().getStringExtra("id");
        Log.d("ADMIN_ID", adminId);


        db = FirebaseFirestore.getInstance();


        binding = ActivityAdminMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.bottomNavBarAdmin.setSelectedItemId(R.id.admin_inbox);
        replaceAdminFragment(new AdminInbox());

        binding.bottomNavBarAdmin.setOnItemSelectedListener(item -> {
            switch(item.getItemId()) {
                case R.id.admin_profile:
                    replaceAdminFragment(new AdminProfile());
                    break;
                case R.id.admin_inbox:
                    replaceAdminFragment(new AdminInbox());
                    break;
                case R.id.admin_processed:
                    replaceAdminFragment(new AdminProcessed());
                    break;
            }
            return true;
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        profile = (ImageView) findViewById(R.id.ProfileBtn);

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                replaceAdminFragment(new AdminProfile());
                binding.bottomNavBarAdmin.setSelectedItemId(R.id.admin_profile);
            }
        });
        DocumentReference adminRef = db.collection("Admins").document(adminId);
        adminRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        adminPic = document.get("picture").toString();

                        Picasso.get().load(adminPic).resize(32, 32).centerCrop().into(profile);
                    }
                }
            }
        });
    }

    private void replaceAdminFragment(Fragment fragment) {
        Bundle bundle = new Bundle();
        bundle.putString("adminId", adminId);
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayoutAdmin,fragment);
        fragmentTransaction.commit();
    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DAY_OF_MONTH, day);
        Timestamp t = new Timestamp(c.getTime());

        DocumentReference docRefCook = db.collection("Cooks").document(Bridge.getCookId());
        docRefCook.update(
                "suspended", true,
                "releaseDate", t
        );

        DocumentReference docRefComplaint = db.collection("Complaints").document(Bridge.getComplaintId());
        docRefComplaint.update(
                "state", "suspended",
                "releaseDate", t
        );

        db.collection("Meals")
                .whereEqualTo("cookId",Bridge.getCookId())
                .get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            for (QueryDocumentSnapshot doc : task.getResult()){
                                db.collection("Meals").document(doc.getId())
                                        .update("suspended",true);
                            }
                        }
                    }
                });
    }
}