package com.group12.mealtime.layout.client;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.group12.mealtime.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ClientMealInfo extends AppCompatActivity {
//ClientViewCook
    private String mealId;
    private String cookId;
    private String clientId;
    private FirebaseFirestore db;

    private TextView mealName;
    private ImageView mealPic;
    private TextView cookName;
    private TextView mealPrice;

    private TextView mealType;
    private TextView cuisineType;
    private TextView mealDescription;
    private ImageView addMealButton;
    private ImageView viewCookButton;

    private RecyclerView ingredientRecyclerView;
    private RecyclerView.Adapter ingredientAdapter;
    private RecyclerView.LayoutManager ingredientLayoutManager;

    private List<String> ingredients = new ArrayList<String>();

    private RecyclerView allergenRecyclerView;
    private RecyclerView.Adapter allergenAdapter;
    private RecyclerView.LayoutManager allergenLayoutManager;

    private List<String> allergens = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.client_meal_info);

        mealId = getIntent().getStringExtra("mealId");
//        cookId = getIntent().getStringExtra("cookId");
        clientId = getIntent().getStringExtra("clientId");

        db = FirebaseFirestore.getInstance();

        mealName = (TextView) findViewById(R.id.tv_clientMealInfoMealName);//done
        mealPic = (ImageView) findViewById(R.id.iv_clientMealInfoMealPic);//done
        cookName = (TextView) findViewById(R.id.tv_clientMealInfoCookName);//done
        mealPrice = (TextView) findViewById(R.id.tv_clientMealInfoMealPrice);//done
        mealType = (TextView) findViewById(R.id.tv_clientMealInfoMealType);//done
        cuisineType = (TextView) findViewById(R.id.tv_clientMealInfoCuisineType);//done
        mealDescription = (TextView) findViewById(R.id.tv_clientMealInfoDescription);//done
        addMealButton = (ImageView) findViewById(R.id.btn_clientAddCookBtn);//done
        viewCookButton = (ImageView) findViewById(R.id.btn_clientViewCook);//done

        addMealButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent reviewIntent = new Intent(ClientMealInfo.this, ClientCheckout.class);
                reviewIntent.putExtra("mealId", mealId);
                reviewIntent.putExtra("clientId",clientId);
                startActivity(reviewIntent);
            }
        });

        viewCookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent complaintIntent = new Intent(ClientMealInfo.this, ClientViewCook.class);
                complaintIntent.putExtra("id", cookId);
                startActivity(complaintIntent);
            }
        });

        ingredientRecyclerView = (RecyclerView) findViewById(R.id.rv_clientCurrentOrderDetailsIngredients);
        ingredientRecyclerView.setNestedScrollingEnabled(false);

        ingredients = new ArrayList<String>();
        ingredientAdapter = new ClientOrderDetailsMealListRecyclerAdapter(ingredients, ClientMealInfo.this);
        ingredientRecyclerView.setAdapter(ingredientAdapter);

        ingredientLayoutManager = new LinearLayoutManager(this);
        ingredientRecyclerView.setLayoutManager(ingredientLayoutManager);

        allergenRecyclerView = (RecyclerView) findViewById(R.id.rv_clientCurrentOrderDetailsAllergens);
        allergenRecyclerView.setNestedScrollingEnabled(false);

        allergens = new ArrayList<String>();
        allergenAdapter = new ClientOrderDetailsMealListRecyclerAdapter(allergens, ClientMealInfo.this);
        allergenRecyclerView.setAdapter(allergenAdapter);

        allergenLayoutManager = new LinearLayoutManager(this);
        allergenRecyclerView.setLayoutManager(allergenLayoutManager);

        DocumentReference mealDoc = db.collection("Meals").document(mealId);

        mealDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()){
                    DocumentSnapshot mealData = task.getResult();

                    if (mealData.exists()){
                        cookId = mealData.get("cookId").toString();
                        mealName.setText(mealData.get("mealName").toString());
                        Picasso.get().load(mealData.get("pic").toString()).resize(100, 100).centerCrop().into(mealPic);
                        mealPrice.setText("$" + mealData.get("price").toString());
                        mealType.setText(mealData.get("mealType").toString());
                        cuisineType.setText(mealData.get("cuisineType").toString());
                        mealDescription.setText(mealData.get("description").toString());
                        ingredients = (List<String>) mealData.get("ingredients");
                        allergens = (List<String>) mealData.get("allergens");
                        ingredientAdapter = new ClientOrderDetailsMealListRecyclerAdapter(ingredients, ClientMealInfo.this);
                        ingredientRecyclerView.setAdapter(ingredientAdapter);
                        allergenAdapter = new ClientOrderDetailsMealListRecyclerAdapter(allergens, ClientMealInfo.this);
                        allergenRecyclerView.setAdapter(allergenAdapter);

                        DocumentReference cookDoc = db.collection("Cooks").document(cookId);
                        cookDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                DocumentSnapshot cookData = task.getResult();
                                cookName.setText(cookData.get("firstName").toString() + " " + cookData.get("lastName").toString());

                            }

                        });
                    }
                }
            }
        });

    }
}
