package com.group12.mealtime.data;

import java.util.HashMap;

public class Account {

    private String id;
    private String email;
    private String type;
    private HashMap<String, String> address;
    private HashMap<String, String> creditCard;
    private String voidCheque;

    public Account() {
    }

    // constructor to be used for Admin
    public Account(String id, String email, String type) {
        this.id = id;
        this.email = email;
        this.type = type;
    }

    // constructor to be used for Client
    public Account(String id, String email, String type, HashMap<String, String> address, HashMap<String, String> creditCard) {
        this(id, email, type);
        this.address = address;
        this.creditCard = creditCard;
    }

    // constructor to be used for Cook
    public Account(String id, String email, String type, String voidCheque) {
        this(id, email, type);
        this.voidCheque = voidCheque;
    }

    public String getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getType() {
        return type;
    }

    public HashMap<String, String> getAddress() {
        return address;
    }

    public HashMap<String, String> getCreditCard() {
        return creditCard;
    }

    public String getVoidCheque() {
        return voidCheque;
    }
}
