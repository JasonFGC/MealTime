package com.group12.mealtime.layout.cook;

import android.content.Context;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.utils.FormValidator;

public class MealListRecyclerViewAdapter extends RecyclerView.Adapter<MealListRecyclerViewAdapter.MyViewHolder> {

    List<String> items;
    Context context;
    boolean editMode;
    private boolean isEditing = false;
    String mealId;
    int type;

    private FirebaseFirestore db;

    public MealListRecyclerViewAdapter(List<String> items, Context context, boolean editMode, String mealId, int type) {
        this.items = items;
        this.context = context;
        this.editMode = editMode;
        this.mealId = mealId;
        this.type = type;
    }

    private void enableEditText(EditText editText) {
        editText.setFocusableInTouchMode(true);
        editText.setEnabled(true);
        editText.setBackgroundResource(android.R.drawable.edit_text);
        editText.setCursorVisible(true);
    }

    private void disableEditText(EditText editText) {
        editText.setFocusable(false);
        editText.setEnabled(false);
        editText.setCursorVisible(false);
        editText.setBackgroundColor(Color.TRANSPARENT);
        editText.setTextColor(Color.rgb(0,0,0));
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.meal_list_item, parent,false);

        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        db = FirebaseFirestore.getInstance();
        DocumentReference mealDoc;
        mealDoc = db.collection("Meals").document(mealId);


        final int currentPositon = position;
        disableEditText(holder.itemName);

        final String itemString = items.get(currentPositon);
        Log.d("ITEMTEST",itemString);
        holder.itemName.setText("\u2022 " + itemString);

        if(editMode) {
            holder.editIcon.setImageResource(R.drawable.editicon);
            holder.editIcon.setVisibility(View.VISIBLE);
            holder.trashIcon.setVisibility(View.VISIBLE);
        } else{
            holder.editIcon.setVisibility(View.GONE);
            holder.trashIcon.setVisibility(View.GONE);
        }

        holder.itemName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                holder.itemName.setTextColor(Color.BLACK);
            }
        });

        holder.editIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isEditing){
                    String currentString = holder.itemName.getText().toString().replace("\u2022 ","");
                    if(!FormValidator.isInvalidMealListItem(currentString)) {
                        disableEditText(holder.itemName);


                        items.set(currentPositon,currentString);

                        if(type == 0){
                            mealDoc.update(
                                    "ingredients",items
                            );
                        }else{
                            mealDoc.update(
                                    "allergens",items
                            );
                        }


                        holder.editIcon.setImageResource(R.drawable.editicon);
                        holder.itemName.setText("\u2022 " + currentString);
                        isEditing = false;
                    } else {
                        holder.itemName.setTextColor(Color.RED);
                    }
                } else{
                    isEditing = true;
                    holder.editIcon.setImageResource(R.drawable.saveicon);
                    Log.d("ITEMTEST",itemString);
                    holder.itemName.setText(itemString);
                    enableEditText(holder.itemName);
                }
            }
        });
        holder.trashIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                items.remove(currentPositon);
                if(type == 0){
                    mealDoc.update(
                            "ingredients",items
                    );
                }else{
                    mealDoc.update(
                            "allergens",items
                    );
                }
            }
        });
    }



    @Override
    public int getItemCount() {
        try {
            return items.size();
        } catch (NullPointerException e) {
            Log.d("NULL_ERROR", e.getMessage());
            return 0;
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        EditText itemName;
        ImageView editIcon;
        ImageView trashIcon;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.tv_clientOrderDetailsMealListItemName);
            editIcon = itemView.findViewById(R.id.iv_mealListItemEditIcon);
            trashIcon = itemView.findViewById(R.id.iv_mealListItemTrashIcon);
        }
    }

}
