package com.group12.mealtime.layout.admin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Complaint;
import com.group12.mealtime.data.Meal;
import com.squareup.picasso.Picasso;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.RecyclerView;

public class ComplaintRecyclerAdapter extends RecyclerView.Adapter<ComplaintRecyclerAdapter.MyViewHolder> {

    private FirebaseFirestore db;
    private CollectionReference complaintsCollection;
    private List<Complaint> complaintList;
    private Context context;

    public ComplaintRecyclerAdapter(List<Complaint> complaintList, Context context) {
        this.complaintList = complaintList;
        this.context = context;
        this.db = FirebaseFirestore.getInstance();
        this.complaintsCollection = db.collection("Complaints");
    }

    @NonNull
    @Override
    public ComplaintRecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.complaint_item_card, parent, false);

        ComplaintRecyclerAdapter.MyViewHolder holder = new ComplaintRecyclerAdapter.MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ComplaintRecyclerAdapter.MyViewHolder holder, int position) {
        Complaint complaint = complaintList.get(position);
        Picasso.get().load(complaint.getClientPic()).resize(40, 40).centerCrop().into(holder.clientProfilePic);
        holder.clientName.setText(complaint.getClientFirstName() + " " + complaint.getClientLastName());
        holder.complaint.setText(complaint.getDescription());
        holder.cookName.setText(complaint.getCookFirstName() + " " + complaint.getCookLastName());
        holder.cookId.setText(complaint.getCookId());

        holder.banBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                complaintsCollection.document(complaint.getId()).update("state", "suspended");
                db.collection("Cooks").document(complaint.getCookId()).update("suspended", true, "releaseDate", null);

                db.collection("Meals")
                        .whereEqualTo("cookId",complaint.getCookId())
                        .get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()){
                                    for (QueryDocumentSnapshot doc : task.getResult()){
                                        db.collection("Meals").document(doc.getId())
                                                .update("suspended",true);
                                    }
                                }
                            }
                        });
            }
        });

        holder.suspendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bridge.setCookId(complaint.getCookId());
                Bridge.setComplaintId(complaint.getId());
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(((AppCompatActivity) context).getSupportFragmentManager(), "Date Picker");
            }
        });

        holder.dismissBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                complaintsCollection.document(complaint.getId()).update("state", "dismissed");
                db.collection("Cooks").document(complaint.getCookId()).update("suspended", false, "releaseDate", null);
            }
        });
    }

    @Override
    public int getItemCount() {
        return complaintList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView clientName;
        TextView complaint;
        TextView cookName;
        TextView cookId;
        ImageView clientProfilePic;
        ImageView banBtn;
        ImageView suspendBtn;
        ImageView dismissBtn;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            clientName = (TextView) itemView.findViewById(R.id.tv_complaint_client_name);
            complaint = (TextView) itemView.findViewById(R.id.tv_complaint);
            cookName = (TextView) itemView.findViewById(R.id.tv_complaint_cook_name);
            cookId = (TextView) itemView.findViewById(R.id.tv_complaint_cook_id);
            clientProfilePic = (ImageView) itemView.findViewById(R.id.iv_complaint_profile_pic);
            banBtn = (ImageView) itemView.findViewById(R.id.iv_ban_btn);
            suspendBtn = (ImageView) itemView.findViewById(R.id.iv_suspend_btn);
            dismissBtn = (ImageView) itemView.findViewById(R.id.iv_dismiss_btn);
        }
    }
}