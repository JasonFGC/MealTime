package com.group12.mealtime.layout.cook;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Switch;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Meal;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CookMenu#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CookMenu extends Fragment {

    List<Meal> mealList = new ArrayList<Meal>();

    private RecyclerView mealRecyclerView;
    private RecyclerView.Adapter mealAdpater;
    private RecyclerView.LayoutManager mealLayoutManager;

    private String cookId;

    private FirebaseFirestore db;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public CookMenu() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CookMenu.
     */
    // TODO: Rename and change types and number of parameters
    public static CookMenu newInstance(String param1, String param2) {
        CookMenu fragment = new CookMenu();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mealRecyclerView = (RecyclerView) getView().findViewById(R.id.mealRecyclerView);


        mealAdpater = new MealRecyclerViewAdapter(mealList,getActivity());
        mealRecyclerView.setAdapter(mealAdpater);
        mealLayoutManager = new LinearLayoutManager(getActivity());
        mealRecyclerView.setHasFixedSize(true);

        mealRecyclerView.setLayoutManager(mealLayoutManager);

        Switch offered = getView().findViewById(R.id.sw_Offered);

        ImageView mealAddBtn =getView().findViewById(R.id.meal_add_btn);

        mealRecyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(getContext(), mealRecyclerView ,new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {
                        // do whatever
                        String mealId;
                        if(offered.isChecked()) {
                            mealId = offeredOnly(mealList).get(position).getId();
                        } else {
                            mealId = mealList.get(position).getId();
                        }

                        Log.d("MEAL_ID1", mealId);
                        Intent editMealIntent = new Intent(getActivity(), CookMealInfo.class);
                        editMealIntent.putExtra("mealId", mealId);
                        startActivity(editMealIntent);
                    }

                    @Override public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );


        db = FirebaseFirestore.getInstance();



        db.collection("Meals")
                .whereEqualTo("cookId", cookId)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {

                    @Override
                    public void onEvent(@Nullable QuerySnapshot value,
                                        @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            Log.d("COMPAINTSs",e.toString());
                            return;
                        }

                        mealList.clear();
                        for (QueryDocumentSnapshot doc : value) {
                            Log.d("MEAL",doc.getId().toString());
                            Log.d("MEAL",doc.get("cuisineType").toString());
                            Log.d("MEAL",doc.get("description").toString());
                            Log.d("MEAL",doc.get("mealName").toString());
                            Log.d("MEAL",doc.get("mealType").toString());
                            Log.d("MEAL",String.valueOf((Boolean) doc.get("offered")));
                            Log.d("MEAL",doc.get("pic").toString());
                            Log.d("MEAL",String.valueOf((Double) doc.get("price")));
                            Meal m = new Meal(doc.getId().toString(), doc.get("cuisineType").toString(),doc.get("description").toString(),doc.get("mealName").toString(),doc.get("mealType").toString(),(Boolean) doc.get("offered"), doc.get("pic").toString(),(Double) doc.get("price"));
                            mealList.add(m);
                        }

                        if(offered.isChecked()){
                            mealAdpater = new MealRecyclerViewAdapter(offeredOnly(mealList),getActivity());
                        }else {
                            mealAdpater = new MealRecyclerViewAdapter(mealList,getActivity());
                        }

                        mealRecyclerView.setAdapter(mealAdpater);
                    }
                });


        offered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(offered.isChecked()){
                    mealAdpater = new MealRecyclerViewAdapter(offeredOnly(mealList),getActivity());
                }else {
                    mealAdpater = new MealRecyclerViewAdapter(mealList,getActivity());
                }

                mealRecyclerView.setAdapter(mealAdpater);
            }
        });

        mealAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String defualtPic = getString(R.string.defualt_meal_src);
                List<String> defualtAllegergens = new ArrayList<String>();
                defualtAllegergens.add("");
                List<String> defualtIngredients = new ArrayList<String>();
                defualtIngredients.add("");
                Meal newMeal = new Meal(defualtAllegergens,cookId,"cuisine","Description",defualtIngredients,"New Name","Meal Type",false,false,defualtPic,0.00);
                db.collection("Meals").add(newMeal).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Intent addMealIntent = new Intent(getActivity(),CookMealInfo.class);
                        addMealIntent.putExtra("mealId",documentReference.getId());
                        getActivity().startActivity(addMealIntent);
                    }
                });
            }
        });


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        cookId = this.getArguments().getString("cookId");
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cook_menu, container, false);
    }

    public List<Meal> offeredOnly(List<Meal> m){
        List<Meal> offeredMeals = new ArrayList<Meal>();

        for(int i = 0; i < mealList.size(); i++){
            if(mealList.get(i).isOffered()){
                offeredMeals.add(mealList.get(i));
            }
        }

        return offeredMeals;
    }
}