package com.group12.mealtime.layout.register;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Account;
import com.group12.mealtime.data.Cook;
import com.group12.mealtime.layout.cook.CookMain;
import com.group12.mealtime.layout.cook.CookMealInfo;
import com.group12.mealtime.utils.FormValidator;

import java.io.File;
import java.util.HashMap;

public class RegisterCook extends AppCompatActivity {
    private boolean formIsValid;

    private boolean firstNameIsValid;
    private boolean lastNameIsValid;

    private boolean streetNumberIsValid;
    private boolean streetNameIsValid;
    private boolean cityIsValid;
    private boolean postalCodeIsValid;

    private boolean descriptionIsValid;


    private EditText firstName;
    private EditText lastName;

    private EditText streetNumber;
    private EditText streetName;
    private EditText city;
    private EditText postalCode;

    private EditText description;
    private ImageView registerButton;
    private ImageView voidCheck;

    private String id;
    private String email;
    private String pic;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private StorageReference storageRef;
    private String voidChequePic;
    private boolean chequeUploaded= false;
    private boolean chequeUploading = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registercook);
        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        email = intent.getStringExtra("email");
        pic = intent.getStringExtra("pic");

        firstName = (EditText) findViewById(R.id.et_firstNameCook);
        lastName = (EditText) findViewById(R.id.et_lastNameCook);

        streetNumber = (EditText) findViewById(R.id.et_streetNumberCook);
        streetName = (EditText) findViewById(R.id.et_streetAddressCook);
        city = (EditText) findViewById(R.id.et_cityCook);
        postalCode = (EditText) findViewById(R.id.et_postalCodeCook);

        registerButton = findViewById(R.id.iv_register);
        voidCheck = findViewById(R.id.iv_voidCheck);
        description=(EditText) findViewById(R.id.et_descriptionCook);
        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageRef = storage.getReference();
        setupEventListeners();


    }

    private void setupEventListeners() {
        firstName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyFirstNameInput();
            }
        });

        lastName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyLastNameInput();
            }
        });

        streetNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyStreetNumberInput();
            }
        });

        streetName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyStreetNameInput();
            }
        });

        city.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyCityInput();
            }
        });

        postalCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyPostalCodeInput();
            }
        });

        description.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                verifyDescriptionInput();
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptRegister();
            }
        });

        voidCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(chequeUploading){
                    Toast.makeText(RegisterCook.this, "Cheque Is Uploading", Toast.LENGTH_SHORT).show();
                } else{
                    if(chequeUploaded){
                        Toast.makeText(RegisterCook.this, "Cheque Already Uploaded", Toast.LENGTH_SHORT).show();
                    } else {
                        ImagePicker.with(RegisterCook.this).compress(256).start(15);
                    }
                }




            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if(requestCode == 15) {
                Uri chequeUri = data.getData();
                Uri chequeFile = Uri.fromFile(new File(chequeUri.getPath()));
                chequeUploading = true;
                StorageReference chequeRef = storageRef.child("cheques/"+chequeFile.getLastPathSegment());
                UploadTask chequePicUpload = chequeRef.putFile(chequeFile);
                chequePicUpload.addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                    }
                });


                Task<Uri> getDownloadUriTask = chequePicUpload.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if (!task.isSuccessful()) {
                            throw task.getException();
                        }

                        return chequeRef.getDownloadUrl();
                    }
                });

                getDownloadUriTask.addOnCompleteListener(RegisterCook.this, new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful()){
                            Uri chequeFireUri = task.getResult();
                            chequeUploading = false;
                            chequeUploaded = true;
                            voidChequePic = chequeFireUri.toString();

                        }
                    }
                });

            }
        }
    }

    private void verifyDescriptionInput(){
        String descriptionText = description.getText().toString();
        // Verify length of input is < 50 characters
        if (FormValidator.isInvalidDescription(descriptionText)) {
            description.setTextColor(Color.RED);
            this.descriptionIsValid = false;
        } else {
            this.descriptionIsValid = true;
            description.setTextColor(Color.BLACK);
        }
        updateFormIsValid();


    }

    private void verifyFirstNameInput() {
        String firstNameText = firstName.getText().toString();
        // Verify length of input is < 20 and it does not contain any numbers [0-9]
        if (FormValidator.isInvalidName(firstNameText)) {
            firstName.setTextColor(Color.RED);
            this.firstNameIsValid = false;
        } else {
            this.firstNameIsValid = true;
            firstName.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyLastNameInput() {
        String lastNameText = lastName.getText().toString();
        // Verify length of input is < 20 and it does not contain any numbers [0-9]
        if (FormValidator.isInvalidName(lastNameText)) {
            lastName.setTextColor(Color.RED);
            this.lastNameIsValid = false;
        } else {
            this.lastNameIsValid = true;
            lastName.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyStreetNumberInput() {
        String streetNumberText = streetNumber.getText().toString();
        // Verify length of input is < 6 and it contains only numbers [0-9]
        if (FormValidator.isInvalidStreetNumber(streetNumberText)) {
            streetNumber.setTextColor(Color.RED);
            this.streetNumberIsValid = false;
        } else {
            this.streetNumberIsValid = true;
            streetNumber.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyStreetNameInput() {
        String streetNameText = streetName.getText().toString();
        // Verify input does not contain numbers [0-9]
        if (FormValidator.isInvalidStreetName(streetNameText)) {
            streetName.setTextColor(Color.RED);
            this.streetNameIsValid = false;
        } else {
            this.streetNameIsValid = true;
            streetName.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyCityInput() {
        String cityNameText = city.getText().toString();
        // Verify length of input is < 86 and does not contain numbers [0-9]
        if (FormValidator.isInvalidCity(cityNameText)) {
            city.setTextColor(Color.RED);
            this.cityIsValid = false;
        } else {
            this.cityIsValid = true;
            city.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyPostalCodeInput() {
        // Get postal code text and remove all BLACKspace
        String postalCodeText = postalCode.getText().toString().replaceAll("\\s+", "");
        // Verify length of input is < 7 and is a valid canadian postal code
        if (FormValidator.isInvalidPostalCode(postalCodeText)) {
            postalCode.setTextColor(Color.RED);
            this.postalCodeIsValid = false;
        } else {
            this.postalCodeIsValid = true;
            postalCode.setTextColor(Color.BLACK);
        }
        updateFormIsValid();
    }

    private void verifyChequeInput() {
        if(chequeUploading){
            Toast.makeText(getApplicationContext(), "Cheque Uploading...", Toast.LENGTH_SHORT).show();
        } else {
            if (!chequeUploaded){
                Toast.makeText(getApplicationContext(), "Please Upload Cheque", Toast.LENGTH_SHORT).show();
            }
        }

        updateFormIsValid();
    }

    private void updateFormIsValid() {
        this.formIsValid = (firstNameIsValid && lastNameIsValid && streetNumberIsValid && streetNameIsValid && cityIsValid && postalCodeIsValid && descriptionIsValid && chequeUploaded);
    }

    private void attemptRegister() {
        Log.d("INFO","ATTEMPREG");
        verifyChequeInput();
        verifyFirstNameInput();
        verifyLastNameInput();
        verifyStreetNumberInput();
        verifyStreetNameInput();
        verifyCityInput();
        verifyPostalCodeInput();
        if (formIsValid) {
            Log.d("INFO","isValid");

            HashMap<String, String> address = new HashMap<String, String>();
            address.put("city", city.getText().toString());
            address.put("country", "Canada");
            address.put("number", streetNumber.getText().toString());
            address.put("postalCode", postalCode.getText().toString());
            address.put("province", "ON");
            address.put("street", streetName.getText().toString());


            Account account = new Account(id,email,"COOK",voidChequePic);
            Cook cook = new Cook(id,firstName.getText().toString(),lastName.getText().toString(),description.getText().toString(),address,0,0,pic,0,null,false);

            db.collection("Accounts").document(id).set(account)
                    .addOnSuccessListener(
                            new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "DocumentSnapshot successfully written!");
                                    db.collection("Cooks").document(id).set(cook)
                                            .addOnSuccessListener(
                                                    new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            Intent intent = new Intent(RegisterCook.this, CookMain.class);
                                                            intent.putExtra("id", id);
                                                            RegisterCook.this.startActivity(intent);
                                                        }
                                                    })
                                            .addOnFailureListener(new OnFailureListener() {
                                                                      @Override
                                                                      public void onFailure(@NonNull Exception e) {
                                                                          Log.w(TAG, "Error writing document", e);
                                                                      }
                                                                  }
                                            );
                                }
                            })
                    .addOnFailureListener(new OnFailureListener() {
                                              @Override
                                              public void onFailure(@NonNull Exception e) {
                                                  Log.w(TAG, "Error writing document", e);
                                              }
                                          }
                    );

        }
    }




}