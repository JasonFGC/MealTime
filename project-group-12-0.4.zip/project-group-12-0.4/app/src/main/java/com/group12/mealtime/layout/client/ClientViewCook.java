package com.group12.mealtime.layout.client;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Review;
import com.group12.mealtime.layout.admin.ComplaintRecyclerAdapter;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ClientViewCook extends AppCompatActivity {

    private List<Review> reviewList = new ArrayList<Review>();

    private FirebaseFirestore db;

    private String cookId;
    private String tempId = "EP6367e831ae8ed505f36edc32";

    private RecyclerView reviewRecyclerView;
    private RecyclerView.Adapter reviewAdapter;
    private RecyclerView.LayoutManager reviewLayoutManager;

    private ImageView cookProfile;
    private TextView cookName;
    private TextView cookRating;
    private TextView cookEmail;
    private TextView cookDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_view_cook);

        cookId = getIntent().getStringExtra("id");

        cookProfile = (ImageView) findViewById(R.id.iv_clientViewCookProfilePic);
        cookName = (TextView) findViewById(R.id.tv_clientViewCookName);
        cookRating = (TextView) findViewById(R.id.tv_clientViewCookRating);
        cookEmail = (TextView) findViewById(R.id.tv_clientViewCookEmail);
        cookDescription = (TextView) findViewById(R.id.tv_clientViewCookDescription);

        reviewRecyclerView = (RecyclerView) findViewById(R.id.rv_clientReviews);

        reviewAdapter = new ReviewRecyclerAdapter(reviewList, this);
        reviewRecyclerView.setAdapter(reviewAdapter);
        reviewLayoutManager = new LinearLayoutManager(this);
        reviewRecyclerView.setHasFixedSize(true);

        reviewRecyclerView.setLayoutManager(reviewLayoutManager);

        db = FirebaseFirestore.getInstance();

        db.collection("Cooks").document(cookId).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    DocumentSnapshot cookData = task.getResult();
                    Picasso.get().load(cookData.get("pic").toString()).resize(125, 125).centerCrop().into(cookProfile);
                    cookName.setText(cookData.get("firstName").toString() + " " + cookData.get("lastName").toString());
                    Double preRating = cookData.getDouble("rating");
                    Double afterRating = (Math.round(preRating * 100.0) / 100.0);
                    cookRating.setText(Double.toString(afterRating));
                    cookDescription.setText(cookData.get("description").toString());
                    db.collection("Accounts").document(cookId).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            DocumentSnapshot accountData = task.getResult();
                            cookEmail.setText(accountData.get("email").toString());
                            db.collection("Reviews").whereEqualTo("cookId", cookId).addSnapshotListener(new EventListener<QuerySnapshot>() {
                                @Override
                                public void onEvent(@Nullable QuerySnapshot querySnapshot, @Nullable FirebaseFirestoreException error) {
                                    for(QueryDocumentSnapshot reviewData : querySnapshot) {
                                        Review review = new Review();
                                        review.setCalculated((boolean) reviewData.get("calculated"));
                                        review.setClientId(reviewData.get("clientId").toString());
                                        review.setCookId(reviewData.get("cookId").toString());
                                        review.setDate((Timestamp) reviewData.get("date"));
                                        review.setDescription(reviewData.get("description").toString());
                                        review.setId(reviewData.getId().toString());
                                        review.setMealId(reviewData.get("mealId").toString());
                                        review.setRating((float) (Math.round(Float.valueOf(reviewData.get("rating").toString()) * 100.0) / 100.0));
                                        reviewList.add(review);
                                    }
                                    reviewAdapter = new ReviewRecyclerAdapter(reviewList, ClientViewCook.this);
                                    reviewRecyclerView.setAdapter(reviewAdapter);
                                }
                            });
                        }
                    });
                }
            });
    }
}