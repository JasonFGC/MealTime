package com.group12.mealtime.layout.cook;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.data.PurchaseRequest;
import com.group12.mealtime.utils.TimeTools;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.List;

public class CookPastRecyclerViewAdapter extends RecyclerView.Adapter<CookPastRecyclerViewAdapter.MyViewHolder> {

    List<PurchaseRequest> prList;
    Context context;

    private FirebaseFirestore db;


    public CookPastRecyclerViewAdapter(List<PurchaseRequest> prList, Context context) {
        this.prList = prList;
        this.context = context;
        db = FirebaseFirestore.getInstance();
    }

    @NonNull
    @Override
    public CookPastRecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cook_past_order, parent,false);

        CookPastRecyclerViewAdapter.MyViewHolder holder = new CookPastRecyclerViewAdapter.MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        String mealId = prList.get(position).getMealId();
        String prId = prList.get(position).getId();
        String clientId = prList.get(position).getClientId();


        DocumentReference mealDoc = db.collection("Meals").document(mealId);
        DocumentReference prDoc = db.collection("PurchaseRequests").document(prId);
        DocumentReference clientDoc = db.collection("Clients").document(clientId);

        Log.d("MEAL IMG",mealId);
        mealDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                Log.d("MEAL IMG","COMLEYE");

                DocumentSnapshot document = task.getResult();
                if(task.isSuccessful()){
                    Log.d("MEAL IMG","SUCC COMLEYE");
                    Log.d("MEAL IMG",String.valueOf( document.exists()));
                    if(document.exists()){
                        Log.d("MEAL IMG","EXIS COMLEYE");
                        Log.d("MEAL IMG",document.get("pic").toString());
                        Picasso.get().load(document.get("pic").toString()).resize(100,100).centerCrop().into(holder.mealImg);
                        holder.mealName.setText(document.get("mealName").toString());
                        holder.mealPrice.setText("$" + ((Double)document.get("price")).toString());
                    }
                }
            }
        });

        clientDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                DocumentSnapshot document = task.getResult();
                if(task.isSuccessful()){
                    if(document.exists()){
                        Picasso.get().load(document.get("picture").toString()).resize(40,40).centerCrop().into(holder.clientImg);
                        holder.clientName.setText((document.get("firstName").toString()) +" "+document.get("lastName").toString());
                    }
                }
            }
        });



        Calendar orderDate = Calendar.getInstance();
        orderDate.setTime(prList.get(position).getOrderDate().toDate());
        int month = orderDate.get(Calendar.MONTH) + 1;
        int day = orderDate.get(Calendar.DAY_OF_MONTH);
        int year = orderDate.get(Calendar.YEAR);
        String dateString = (
                String.format("%02d", month) +
                        " / " + String.format("%02d", day) + " / " +
                        year
        );
        holder.orderTime.setText(dateString);


        Calendar pickupDate = Calendar.getInstance();
        pickupDate.setTime(prList.get(position).getPickupTime().toDate());
        long currentTime = Calendar.getInstance().getTimeInMillis();
        long pickupTime = pickupDate.getTimeInMillis();
        long minutes = TimeTools.toMinutes(pickupTime - currentTime);
        if(minutes <= 0) {
            holder.pickupTime.setText((minutes * -1) + " min late");
            holder.pickupTime.setTextColor(Color.RED);
        } else {
            holder.pickupTime.setText(minutes + " min");
        }


    }

    @Override
    public int getItemCount() {
        try {
            return prList.size();
        } catch (NullPointerException e) {
            Log.d("NULL_ERROR", e.getMessage());
            return 0;
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView clientImg;
        ImageView mealImg;
        TextView pickupTime;
        TextView orderTime;
        TextView clientName;
        TextView mealName;
        TextView mealPrice;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            mealImg = itemView.findViewById(R.id.iv_meal_pic);
            mealName = itemView.findViewById(R.id.tv_meal_name);
            clientName = itemView.findViewById(R.id.tv_client_name);
            mealPrice = itemView.findViewById(R.id.tv_price_cop);

            clientImg = itemView.findViewById(R.id.iv_client_pic);
            pickupTime = itemView.findViewById(R.id.tv_pickup_time_result);
            orderTime = itemView.findViewById(R.id.tv_order_date);

        }
    }
}
