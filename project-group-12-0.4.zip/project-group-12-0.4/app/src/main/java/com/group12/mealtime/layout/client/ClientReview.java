package com.group12.mealtime.layout.client;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.slider.Slider;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Complaint;
import com.group12.mealtime.data.Review;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.Calendar;

public class ClientReview extends AppCompatActivity {

    private String prId;
    private FirebaseFirestore db;

    private ImageView mealPic;
    private TextView mealName;
    private TextView mealType;
    private TextView cuisineType;
    private TextView mealDescription;
    private TextView orderDate;
    private EditText review;
    private TextView reviewValue;
    private Slider reviewSlider;
    private ImageView doneBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_review);

        db = FirebaseFirestore.getInstance();
        prId = getIntent().getStringExtra("id");

        mealPic = (ImageView) findViewById(R.id.iv_clientReviewMealPic);
        mealName = (TextView) findViewById(R.id.tv_clientReviewMealName);
        mealType = (TextView) findViewById(R.id.tv_clientReviewMealType);
        cuisineType = (TextView) findViewById(R.id.tv_clientReviewCuisineType);
        mealDescription = (TextView) findViewById(R.id.tv_clientReviewMealDescription);
        orderDate = (TextView) findViewById(R.id.tv_clientReviewOrderDate);
        review = (EditText) findViewById(R.id.et_clientReview);
        review.setText("");
        reviewValue = (TextView) findViewById(R.id.tv_reviewNumSlideValue);
        reviewSlider = (Slider) findViewById(R.id.slider);
        doneBtn = (ImageView) findViewById(R.id.btn_doneReview);

        reviewSlider.addOnChangeListener(new Slider.OnChangeListener() {
            @Override
            public void onValueChange(@NonNull Slider slider, float value, boolean fromUser) {
                value = (float) (Math.round(value * 100.0) / 100.0);
                reviewValue.setText("Review (" + String.format("%.2f", value) + "/5):");
            }
        });

        doneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Review review = new Review();
                review.setCalculated(false);
                review.setDescription(ClientReview.this.review.getText().toString());
                review.setRating(reviewSlider.getValue());
                review.setDate(new Timestamp(Calendar.getInstance().getTime()));
                DocumentReference prDoc = db.collection("PurchaseRequests").document(prId);
                prDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        DocumentSnapshot docRef = task.getResult();
                        review.setClientId(docRef.get("clientId").toString());
                        review.setCookId(docRef.get("cookId").toString());
                        review.setMealId(docRef.get("mealId").toString());
                        db.collection("Reviews").add(review).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                documentReference.update("id", documentReference.getId());
                                db.collection("Cooks").document(review.getCookId()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                        DocumentSnapshot cookData = task.getResult();
                                        double currentRating = cookData.getDouble("rating");
                                        db.collection("Reviews")
                                                .whereEqualTo("cookId", review.getCookId())
                                                .get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                int numRatings = 0;
                                                double ratingSum = 0;
                                                for(QueryDocumentSnapshot reviewData : task.getResult()) {
                                                    ratingSum += reviewData.getDouble("rating");
                                                    numRatings++;
                                                }
                                                double newRating = ratingSum / numRatings;
                                                db.collection("Cooks").document(review.getCookId()).update("rating", newRating);
                                            }
                                        });
                                    }
                                });
//                                Intent intent = new Intent(ClientReview.this, ClientCurrentOrderDetails.class);
//                                intent.putExtra("id", prId);
//                                startActivity(intent);
                                finish();
                            }
                        });
                    }
                });
            }
        });

        DocumentReference prDoc = db.collection("PurchaseRequests").document(prId);
        prDoc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot doc, @Nullable FirebaseFirestoreException error) {
                DocumentReference mealDoc = db.collection("Meals").document(doc.get("mealId").toString());
                mealDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        DocumentSnapshot mealData = task.getResult();
                        mealName.setText(mealData.get("mealName").toString());
                        Picasso.get().load(mealData.get("pic").toString()).resize(120, 120).centerCrop().into(mealPic);
                        mealType.setText(mealData.get("mealType").toString());
                        cuisineType.setText(mealData.get("cuisineType").toString());
                        mealDescription.setText(mealData.get("description").toString());
                    }
                });
                Calendar orderDate = Calendar.getInstance();
                orderDate.setTime(((Timestamp) doc.get("orderDate")).toDate());
                int month = orderDate.get(Calendar.MONTH) + 1;
                int day = orderDate.get(Calendar.DAY_OF_MONTH);
                int year = orderDate.get(Calendar.YEAR);
                String dateString = (
                        String.format("%02d", month) +
                                " / " + String.format("%02d", day) + " / " +
                                year
                );
                ClientReview.this.orderDate.setText(dateString);
            }
        });

    }
}