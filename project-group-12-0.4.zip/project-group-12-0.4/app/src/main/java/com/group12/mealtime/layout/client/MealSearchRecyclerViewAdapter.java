package com.group12.mealtime.layout.client;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.group12.mealtime.R;
import com.group12.mealtime.data.Meal;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MealSearchRecyclerViewAdapter extends RecyclerView.Adapter<MealSearchRecyclerViewAdapter.MyViewHolder> {

    List<Meal> mealList;
    Context context;
    String clientId;

    public MealSearchRecyclerViewAdapter(List<Meal> mealList, Context context, String clientId) {
        this.mealList = mealList;
        this.context = context;
        this.clientId = clientId;
    }

    @NonNull
    @Override
    public MealSearchRecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.meal_item_search_card, parent,false);

        MealSearchRecyclerViewAdapter.MyViewHolder holder = new MealSearchRecyclerViewAdapter.MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.mealName.setText(mealList.get(position).getMealName().substring(0,Math.min(15,mealList.get(position).getMealName().length())));
        holder.mealDesc.setText(mealList.get(position).getDescription().substring(0,Math.min(100,mealList.get(position).getDescription().length())));
        holder.mealPrice.setText("$".concat(String.valueOf(mealList.get(position).getPrice())));
        holder.cType.setText(mealList.get(position).getCuisineType().substring(0,Math.min(10,mealList.get(position).getCuisineType().length())));
        holder.mType.setText(mealList.get(position).getMealType().substring(0,Math.min(10,mealList.get(position).getMealType().length())));
        Picasso.get().load(mealList.get(position).getPic()).resize(100,100).centerCrop().into(holder.mealImg);

        holder.AddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addIntent = new Intent(context, ClientCheckout.class);
                addIntent.putExtra("mealId",mealList.get(position).getId());
                addIntent.putExtra("clientId",clientId);
                context.startActivity(addIntent);
            }
        });

        holder.ViewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewIntent = new Intent(context, ClientMealInfo.class);
                viewIntent.putExtra("mealId",mealList.get(position).getId());
                viewIntent.putExtra("clientId",clientId);
                context.startActivity(viewIntent);
            }
        });

    }

    @Override
    public int getItemCount() {
        try {
            return mealList.size();
        } catch (NullPointerException e) {
            Log.d("NULL_ERROR", e.getMessage());
            return 0;
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView mealImg;
        ImageView AddBtn;
        ImageView ViewBtn;
        TextView mealName;
        TextView mealDesc;
        TextView cType;
        TextView mType;
        TextView mealPrice;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            mealImg = itemView.findViewById(R.id.iv_meal);
            AddBtn = itemView.findViewById(R.id.addBTN);
            ViewBtn = itemView.findViewById(R.id.viewBtn);
            mealName = itemView.findViewById(R.id.tv_name);
            mealDesc = itemView.findViewById(R.id.tv_desc);
            cType = itemView.findViewById(R.id.tv_cType);
            mType = itemView.findViewById(R.id.tv_mType);
            mealPrice = itemView.findViewById(R.id.tv_price);
        }
    }
}
