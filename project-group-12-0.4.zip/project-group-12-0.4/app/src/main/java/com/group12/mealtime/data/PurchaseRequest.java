package com.group12.mealtime.data;

import com.google.firebase.Timestamp;

public class PurchaseRequest {

    private String id;
    private String mealId;
    private String clientId;
    private String cookId;
    private Timestamp pickupTime;
    private String state;
    private Timestamp orderDate;

    public PurchaseRequest(){};

    public PurchaseRequest(String id, String mealId, String clientId, String cookId, com.google.firebase.Timestamp pickupTime, String state, Timestamp orderDate) {
        this.id = id;
        this.mealId = mealId;
        this.clientId = clientId;
        this.cookId = cookId;
        this.pickupTime = pickupTime;
        this.state = state;
        this.orderDate = orderDate;
    }

    public String getId() {
        return id;
    }

    public String getMealId() {
        return mealId;
    }

    public String getClientId() {
        return clientId;
    }

    public String getCookId() {
        return cookId;
    }

    public Timestamp getPickupTime() {
        return pickupTime;
    }

    public String getState() {
        return state;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }
}
