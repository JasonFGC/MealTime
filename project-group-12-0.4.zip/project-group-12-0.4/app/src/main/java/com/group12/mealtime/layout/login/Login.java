package com.group12.mealtime.layout.login;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.auth0.android.Auth0;
import com.auth0.android.authentication.AuthenticationException;
import com.auth0.android.callback.Callback;
import com.auth0.android.provider.WebAuthProvider;
import com.auth0.android.result.Credentials;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.layout.admin.AdminMain;
import com.group12.mealtime.layout.client.ClientMain;
import com.group12.mealtime.layout.cook.CookMain;
import com.group12.mealtime.layout.cook.CookSuspend;
import com.group12.mealtime.layout.register.Register;

import java.util.Date;

public class Login extends AppCompatActivity {


    private Auth0 account;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);


        setContentView(R.layout.activity_login);

        account = new Auth0(getString(R.string.com_auth0_client_id), getString(R.string.com_auth0_domain));
        db = FirebaseFirestore.getInstance();
    }


    public void loginwithBrowser(View view){
        Callback<Credentials, AuthenticationException> callback = new Callback<Credentials, AuthenticationException>() {

            @Override
            public void onFailure(@NonNull AuthenticationException exception) {
                //failed with an exception
            }

            @Override
            public void onSuccess(@Nullable Credentials credentials) {
                //succeeded!

                String[] userIdProv = credentials.getUser().getId().toString().split("\\|");

                Log.d("INFO",credentials.getUser().getId().toString());
                Log.d("INFO",credentials.getUser().getEmail().toString());

                Log.d("Info", userIdProv[0]);
                Log.d("Info", userIdProv[1]);
                String userId;
                if (userIdProv[0].equals("google-oauth2")){
                    userId = "GO"+userIdProv[1];
                } else {
                    userId = "EP"+userIdProv[1];
                }

                Log.d("Info", userId);

                DocumentReference docRef = db.collection("Accounts").document(userId);
                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                String userType = document.get("type").toString();
                                if (userType.equals("ADMIN")) {
                                    Intent adminIntent = new Intent(Login.this, AdminMain.class);
                                    adminIntent.putExtra("id", userId);
                                    Login.this.startActivity(adminIntent);
                                } else if (userType.equals("COOK")) {
                                    DocumentReference docRef = db.collection("Cooks").document(userId);
                                    docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                            if (task.isSuccessful()) {
                                                DocumentSnapshot cookDoc = task.getResult();
                                                if (cookDoc.exists()) {
                                                    boolean suspended = (boolean) cookDoc.get("suspended");

                                                    Timestamp releaseDate;
                                                    if (cookDoc.get("releaseDate") != null) {
                                                        releaseDate = (Timestamp) cookDoc.get("releaseDate");
                                                        Date currentDate = new Date();
                                                        if (currentDate.after(releaseDate.toDate())) {
                                                            updateSuspension(userId);
                                                            suspended = false;
                                                        }
                                                    }
                                                    if (suspended == true) {
                                                        Intent cookSuspend = new Intent(Login.this, CookSuspend.class);
                                                        cookSuspend.putExtra("id", userId);
                                                        Login.this.startActivity(cookSuspend);
                                                    } else {
                                                        Intent cookIntent = new Intent(Login.this, CookMain.class);
                                                        cookIntent.putExtra("id", userId);
                                                        Login.this.startActivity(cookIntent);
                                                    }
                                                }
                                            }
                                        }
                                    });

                                } else if (userType.equals("CLIENT")) {
                                    Intent clientIntent = new Intent(Login.this, ClientMain.class);
                                    clientIntent.putExtra("id", userId);
                                    Login.this.startActivity(clientIntent);
                                } else {
                                    Log.e("ACCOUNT TYPE EXCEPTION", "unrecognized account type: " + userType);
                                }
                            } else {
                                Intent RegIntent = new Intent(Login.this, Register.class);
                                RegIntent.putExtra("id",userId );
                                RegIntent.putExtra("email",credentials.getUser().getEmail() );
                                RegIntent.putExtra("pic",credentials.getUser().getPictureURL());
                                Login.this.startActivity(RegIntent);
                            }
                        } else {
                            Log.d("INFO", "get failed with ", task.getException());
                        }
                    }
                });

            }
        };

        WebAuthProvider.login(account)
                .withScheme("demo")
                .start(this, callback);
    }
    private void updateSuspension(String cookId) {
        DocumentReference docRefCook = db.collection("Cooks").document(cookId);
        docRefCook.update(
                "suspended", false,
                "releaseDate", null
        );
    }


}