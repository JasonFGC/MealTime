package com.group12.mealtime.data;

import com.google.firebase.Timestamp;

import java.util.ArrayList;
import java.util.HashMap;

public class Cook {

    private String id;
    private String firstName;
    private String lastName;
    private String description;
    private HashMap<String, String> address;
    private int mealsSold;
    private int numReviews;
    private String pic;
    private double rating;
    private Timestamp releaseDate;
    private boolean suspended;

    public Cook() {}

    public Cook(String id, String firstName, String lastName, String description, HashMap<String, String> address, int mealsSold, int numReviews, String pic, double rating, Timestamp releaseDate, boolean suspended) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.description = description;
        this.address = address;
        this.mealsSold = mealsSold;
        this.numReviews = numReviews;
        this.pic = pic;
        this.rating = rating;
        this.releaseDate = releaseDate;
        this.suspended = suspended;
    }

    public String getId(){
        return id;
    }

    public String getFirstName(){
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDescription() {
        return description;
    }

    public HashMap<String, String> getAddress() {
        return address;
    }

    public int getMealsSold() {
        return mealsSold;
    }


    public int getNumReviews() {
        return numReviews;
    }

    public String getPic() {
        return pic;
    }


    public double getRating() {
        return rating;
    }

    public Timestamp getReleaseDate() {
        return releaseDate;
    }

    public boolean isSuspended() {
        return suspended;
    }
}
