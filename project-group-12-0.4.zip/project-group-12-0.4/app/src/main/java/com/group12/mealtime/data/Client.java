package com.group12.mealtime.data;

import java.util.ArrayList;
import java.util.HashMap;

public class Client {

    private String id;
    private String firstName;
    private String lastName;
    private String picture;

    public Client() {}

    public Client(String id, String firstName, String lastName, String picture) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.picture = picture;
    }


    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPicture() {
        return picture;
    }

}
