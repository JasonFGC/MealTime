package com.group12.mealtime.data;

import java.util.List;

public class Meal {
    private String id;
    private List<String> allergens;
    private String cookId;
    private String cuisineType;
    private String description;
    private List<String> ingredients;
    private String mealName;
    private String mealType;
    private boolean offered;
    private boolean suspended;
    private String cookFirstName;
    private String cookLastName;
    private String pic;
    private double price;

    public Meal(){};

    public Meal(List<String> allergens, String cookId, String cuisineType, String description, List<String> ingredients, String mealName, String mealType, boolean offered, boolean suspended, String pic, double price) {
        this.allergens = allergens;
        this.cookId = cookId;
        this.cuisineType = cuisineType;
        this.description = description;
        this.ingredients = ingredients;
        this.mealName = mealName;
        this.mealType = mealType;
        this.offered = offered;
        this.suspended = suspended;
        this.pic = pic;
        this.price = price;
    }


    public Meal(String id, String cuisineType, String description, String mealName, String mealType, boolean offered, String pic, double price) {
        this.id = id;
        this.cuisineType = cuisineType;
        this.description = description;
        this.mealName = mealName;
        this.mealType = mealType;
        this.offered = offered;
        this.pic = pic;
        this.price = price;
    }



    public Meal(String id, List<String> allergens, String cookId, String cuisineType, String description, List<String> ingredients, String mealName, String mealType, boolean offered, boolean suspended, String cookFirstName, String cookLastName, String pic, double price) {
        this.id = id;
        this.allergens = allergens;
        this.cookId = cookId;
        this.cuisineType = cuisineType;
        this.description = description;
        this.ingredients = ingredients;
        this.mealName = mealName;
        this.mealType = mealType;
        this.offered = offered;
        this.suspended = suspended;
        this.cookFirstName = cookFirstName;
        this.cookLastName = cookLastName;
        this.pic = pic;
        this.price = price;
    }



    public String getId() {
        return id;
    }

    public List<String> getAllergens() {
        return allergens;
    }

    public String getCookId() {
        return cookId;
    }

    public String getCuisineType() {
        return cuisineType;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public String getMealName() {
        return mealName;
    }

    public String getMealType() {
        return mealType;
    }

    public boolean isOffered() {
        return offered;
    }

    public String getPic() {
        return pic;
    }

    public double getPrice() {
        return price;
    }


    public void setId(String id) {
        this.id = id;
    }

    public void setAllergens(List<String> allergens) {
        this.allergens = allergens;
    }

    public void setCookId(String cookId) {
        this.cookId = cookId;
    }

    public void setCuisineType(String cuisineType) {
        this.cuisineType = cuisineType;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }

    public void setMealName(String mealName) {
        this.mealName = mealName;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

    public void setOffered(boolean offered) {
        this.offered = offered;
    }

    public void setSuspended(boolean suspended) {
        this.suspended = suspended;
    }

    public void setCookFirstName(String cookFirstName) {
        this.cookFirstName = cookFirstName;
    }

    public void setCookLastName(String cookLastName) {
        this.cookLastName = cookLastName;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
