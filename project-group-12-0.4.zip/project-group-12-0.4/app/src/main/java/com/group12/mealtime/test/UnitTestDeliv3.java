package com.group12.mealtime.test;

import com.group12.mealtime.utils.FormValidator;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class UnitTestDeliv3 {
    @Test
    public void testCityIsInValid() {
        String invalidCity = "1234";
        assertTrue(FormValidator.isInvalidCity(invalidCity));
    }
    @Test
    public void testCvvIsiInValid() {
        String invalidCvv = "cvv";
        assertTrue(FormValidator.isInvalidCvv(invalidCvv));
    }
    @Test
    public void testPostCodeIsiInValid() {
        String invalidPostalC = "H4V";
        assertTrue(FormValidator.isInvalidPostalCode(invalidPostalC));
    }
    @Test
    public void testInvalidCreditCardExpDate() {
        String InvalidCreditCardExpDate = "November fifth";
        assertTrue(FormValidator.isInvalidPostalCode(InvalidCreditCardExpDate));

    }
}
