package com.group12.mealtime.layout.admin;

public class Bridge {
    private static String cookId;
    private static String complaintId;

    public static String getCookId() {
        return cookId;
    }

    public static void setCookId(String cookId) {
        Bridge.cookId = cookId;
    }

    public static String getComplaintId() {
        return complaintId;
    }

    public static void setComplaintId(String complaintId) {
        Bridge.complaintId = complaintId;
    }
}
