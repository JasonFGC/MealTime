package com.group12.mealtime.layout.cook;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.auth0.android.Auth0;
import com.auth0.android.authentication.AuthenticationException;
import com.auth0.android.callback.Callback;
import com.auth0.android.provider.WebAuthProvider;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Cook;
import com.group12.mealtime.layout.login.Login;

import java.util.Calendar;
import java.util.Date;

public class CookSuspend extends AppCompatActivity {

    private Auth0 account;
    private FirebaseFirestore db;
    private Cook cook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cook_suspend);
        account = new Auth0(getString(R.string.com_auth0_client_id), getString(R.string.com_auth0_domain));
        db = FirebaseFirestore.getInstance();

        Intent intent = getIntent();
        String cookId = intent.getStringExtra("id");

        TextView suspensionStatus = (TextView) findViewById(R.id.suspensionStatus);
        TextView suspendDesc = (TextView) findViewById(R.id.suspendDescription);

        DocumentReference docRef = db.collection("Cooks").document(cookId);
        docRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot snapshot,
                                @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w("CookHome", "Listen failed.", e);
                    return;
                }

                if (snapshot != null && snapshot.exists()) {
                    String firstName = snapshot.get("firstName").toString();
                    boolean suspended = (boolean) snapshot.get("suspended");
                    boolean releaseDateNull = false;
                    Timestamp releaseDate;
                    if(snapshot.get("releaseDate") != null) {
                        releaseDate = (Timestamp) snapshot.get("releaseDate");
                        Date currentDate = new Date();
                        if(currentDate.after(releaseDate.toDate())) {
                            updateSuspension(cookId);
                        }
                        if(suspended) {

                            Calendar calendar = Calendar.getInstance();
                            calendar.setTime(releaseDate.toDate());
                            int month = calendar.get(Calendar.MONTH) + 1;
                            int day = calendar.get(Calendar.DAY_OF_MONTH);
                            int year = calendar.get(Calendar.YEAR);
                            String dateString = (
                                    String.format("%02d", month) +
                                            " / " + String.format("%02d", day) + " / " +
                                            year
                            );
                            suspensionStatus.setText("Your account has been temporarily suspended until, "+ dateString);
                            suspendDesc.setText("You have been temporarily suspended from Meal Time for violating our Terms of Service. " +
                                    "\n\n Please refer to the time specified above to see when you will be able to use our service again." +
                                    "\n\n In the mean-time, please refrain from using our service as it is against the law. " +
                                    "\n\n Thank you for understanding." +
                                    "\n\n-Meal Time team");
                        }
                    } else {
                        if(suspended) {
                            suspensionStatus.setText("Your account has been permanently suspended");
                            suspendDesc.setText("You have been banned Meal Time for violating our Terms of Service. \n\nPlease refrain from using our service as it is against the law. \n\nThank you for understanding. \n\n-Meal Time team");
                        } else {
                            logoutWithCode();
                            suspensionStatus.setText("Welcome to Meal Time!");
                        }
                    }


                    Log.d("CookHome", "Current data: " + snapshot.getData());
                } else {
                    Log.d("CookHome", "Current data: real-null");
                }
            }
        });
    }

    private void updateSuspension(String cookId) {
        DocumentReference docRefCook = db.collection("Cooks").document(cookId);
        docRefCook.update(
                "suspended", false,
                "releaseDate", null
        );

        db.collection("Meals")
                .whereEqualTo("cookId",cookId)
                .get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            for (QueryDocumentSnapshot doc : task.getResult()){
                                db.collection("Meals").document(doc.getId())
                                        .update("suspended",false);
                            }
                        }
                    }
                });
    }


    public void logout(View view){
        //Declare the callback that will receive the result
        Callback<Void, AuthenticationException> logoutCallback = new Callback<Void, AuthenticationException>() {
            @Override
            public void onFailure(@NonNull AuthenticationException e) {

            }

            @Override
            public void onSuccess(@Nullable Void payload) {
                //succeeded!
                Log.d("INFO", "Logged Out");
                CookSuspend.this.startActivity(new Intent(CookSuspend.this, Login.class));

            }
        };

        WebAuthProvider.logout(account)
                .withScheme("demo")
                .start(CookSuspend.this, logoutCallback);

        //Configure and launch the log out




    }
    public void logoutWithCode(){
        Callback<Void, AuthenticationException> logoutCallback = new Callback<Void, AuthenticationException>() {
            @Override
            public void onFailure(@NonNull AuthenticationException e) {

            }

            @Override
            public void onSuccess(@Nullable Void payload) {
                //succeeded!
                Log.d("INFO", "Logged Out");
                CookSuspend.this.startActivity(new Intent(CookSuspend.this,Login.class));

            }
        };

        WebAuthProvider.logout(account)
                .withScheme("demo")
                .start(CookSuspend.this, logoutCallback);
    }
}