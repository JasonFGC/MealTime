package com.group12.mealtime.layout.client;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.auth0.android.Auth0;
import com.auth0.android.authentication.AuthenticationException;
import com.auth0.android.callback.Callback;
import com.auth0.android.provider.WebAuthProvider;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Account;
import com.group12.mealtime.data.Client;
import com.group12.mealtime.data.Cook;
import com.group12.mealtime.layout.cook.CookPastOrders;
import com.group12.mealtime.layout.cook.CookProfile;
import com.group12.mealtime.layout.login.Login;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class ClientProfile extends AppCompatActivity {

    private Auth0 account;
    String clientId;

    Client client;
    Account aclient;
    private FirebaseFirestore db;

    ImageView clientImg;
    TextView Name;
    TextView Address;
    TextView Email;
    TextView creditCard;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_profile);
    }

    @Override
    protected void onStart() {
        super.onStart();
        clientImg = findViewById(R.id.iv_clientPic);
        Name = findViewById(R.id.tv_pcname);
        Address = findViewById(R.id.tv_pcaddress);
        Email = findViewById(R.id.tv_pcemail);
        creditCard = findViewById(R.id.tv_pcredit);

        db = FirebaseFirestore.getInstance();

        clientId = getIntent().getStringExtra("id");
        Log.d("TEST",clientId);
        DocumentReference cookRef = db.collection("Clients").document(clientId);
        cookRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot doc = task.getResult();

                    if (doc.exists()) {

                        client = new Client(doc.getId(), doc.getString("firstName"), doc.getString("lastName"), doc.getString("picture"));
                        Log.d("TEST",client.getPicture());
                        Picasso.get().load(client.getPicture()).resize(150, 150).centerCrop().into(clientImg);
                        Name.setText(client.getFirstName() + " " + client.getLastName());

                    }
                }
            }
        });

        DocumentReference accountRef = db.collection("Accounts").document(clientId);
        accountRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot doc = task.getResult();
                    if (doc.exists()) {
                        aclient = new Account(doc.getId(),doc.getString("email"),"COOK", (HashMap<String, String>) doc.get("address"), (HashMap<String, String>) doc.get("creditCard"));

                        String addressString =
                                aclient.getAddress().get("number") + " "
                                        + aclient.getAddress().get("street") + ", "
                                        + aclient.getAddress().get("city") + ", "
                                        + aclient.getAddress().get("province") + ", "
                                        + aclient.getAddress().get("country") + ", "
                                        + aclient.getAddress().get("postalCode");

                        Address.setText(addressString);
                        Email.setText(aclient.getEmail());

                        String creditString =
                            "Number: "
                            + aclient.getCreditCard().get("number")
                            + "\nExpiry: "
                            + aclient.getCreditCard().get("exp")
                            + "\nCVV: "
                            + aclient.getCreditCard().get("cvv");

                        creditCard.setText(creditString);
                    }
                }
            }
        });



        ImageView pastOrderBtn = findViewById(R.id.btn_cpastorders);

        pastOrderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pastorderIntent = new Intent(ClientProfile.this, ClientPastOrders.class);
                pastorderIntent.putExtra("id",clientId);
                startActivity(pastorderIntent);
            }
        });



        account = new Auth0(getString(R.string.com_auth0_client_id), getString(R.string.com_auth0_domain));
        ImageView logout = findViewById(R.id.btn_clogout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Declare the callback that will receive the result
                Callback<Void, AuthenticationException> logoutCallback = new Callback<Void, AuthenticationException>() {
                    @Override
                    public void onFailure(@NonNull AuthenticationException e) {

                    }

                    @Override
                    public void onSuccess(@Nullable Void payload) {
                        //succeeded!
                        Log.d("INFO", "Logged Out");
                        startActivity(new Intent(ClientProfile.this, Login.class));

                    }
                };

                WebAuthProvider.logout(account)
                        .withScheme("demo")
                        .start(ClientProfile.this, logoutCallback);

                //Configure and launch the log out
            }
        });
    }
}