package com.group12.mealtime.data;

import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class Complaint {

    private String clientPic;
    private String clientLastName;
    private Timestamp releaseDate;
    private String clientFirstName;

    private String id;
    private String cookId;
    private String cookFirstName;
    private String cookLastName;
    private String description;
    private String state;


    public Complaint(){};

    public Complaint(String cookId, String cookFirstName, String cookLastName, String description, String state, String complaintId, Timestamp releaseDate,
                     String clientFirstName, String clientLastName, String clientPic) {
        this.cookFirstName = cookFirstName;
        this.cookLastName = cookLastName;
        this.description = description;
        this.state = state;
        this.cookId = cookId;
        this.id = complaintId;
        this.releaseDate = releaseDate;
        this.clientFirstName = clientFirstName;
        this.clientLastName = clientLastName;
        this.clientPic = clientPic;
    }

    public void setClientPic(String clientPic) {
        this.clientPic = clientPic;
    }

    public void setClientLastName(String clientLastName) {
        this.clientLastName = clientLastName;
    }

    public void setReleaseDate(Timestamp releaseDate) {
        this.releaseDate = releaseDate;
    }

    public void setClientFirstName(String clientFirstName) {
        this.clientFirstName = clientFirstName;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setCookId(String cookId) {
        this.cookId = cookId;
    }

    public void setCookFirstName(String cookFirstName) {
        this.cookFirstName = cookFirstName;
    }

    public void setCookLastName(String cookLastName) {
        this.cookLastName = cookLastName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getId() {
        return id;
    }

    public String getClientPic() {
        return clientPic;
    }

    public String getClientLastName() {
        return clientLastName;
    }

    public Timestamp getReleaseDate() {
        return releaseDate;
    }

    public String getClientFirstName() {
        return clientFirstName;
    }

    public String getCookId() {
        return cookId;
    }


    public String getDescription() {
        return description;
    }


    public String getState() {
        return state;
    }

    public String getCookFirstName() {
        return cookFirstName;
    }

    public String getCookLastName() {
        return cookLastName;
    }
}
