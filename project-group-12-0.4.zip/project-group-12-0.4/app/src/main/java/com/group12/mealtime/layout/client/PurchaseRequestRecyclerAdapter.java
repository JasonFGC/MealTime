package com.group12.mealtime.layout.client;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.group12.mealtime.R;
import com.group12.mealtime.data.PurchaseRequest;
import com.group12.mealtime.utils.TimeTools;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PurchaseRequestRecyclerAdapter extends RecyclerView.Adapter<PurchaseRequestRecyclerAdapter.MyViewHolder> {

    FirebaseFirestore db;
    CollectionReference purchaseRequestsCollection;
    List<PurchaseRequest> purchaseRequestList;
    Context context;

    public PurchaseRequestRecyclerAdapter(List<PurchaseRequest> purchaseRequestList, Context context) {
        this.purchaseRequestList = purchaseRequestList;
        this.context = context;
        this.db = FirebaseFirestore.getInstance();
        this.purchaseRequestsCollection = db.collection("PurchaseRequests");
    }

    @NonNull
    @Override
    public PurchaseRequestRecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.client_current_order_card, parent, false);

        PurchaseRequestRecyclerAdapter.MyViewHolder holder = new PurchaseRequestRecyclerAdapter.MyViewHolder(view);
        return holder;
    }

    private void setMargins (View view, int left, int top, int right, int bottom) {
        if (view.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams p = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
            p.setMargins(left, top, right, bottom);
            view.requestLayout();
        }
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        PurchaseRequest pr = purchaseRequestList.get(position);
        if(pr.getState().equals("cooked")) {
            setMargins(holder.viewDetailsBtn,5, 10, 0, 0);
            holder.pickupBtn.setVisibility(View.VISIBLE);
            holder.mealStatus.setText("Cooked (ready for pickup)");
            holder.mealStatus.setTextColor(Color.rgb(0, 214, 143));
        } else if (pr.getState().equals("approved") || pr.getState().equals("picked") ||pr.getState().equals("rejected")) {
            setMargins(holder.viewDetailsBtn,5, 10, 0, 11);
            holder.pickupBtn.setVisibility(View.GONE);
            holder.mealStatus.setText(pr.getState());
            holder.mealStatus.setTextColor(Color.rgb(214, 154, 0));
        }
        holder.viewDetailsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent orderDetailsIntent = new Intent(context, ClientCurrentOrderDetails.class);
                orderDetailsIntent.putExtra("id", pr.getId());
                orderDetailsIntent.putExtra("cookId", pr.getCookId());
                orderDetailsIntent.putExtra("clientId", pr.getClientId());
                context.startActivity(orderDetailsIntent);
            }
        });
        holder.pickupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                purchaseRequestsCollection.document(pr.getId()).update("state", "picked");
            }
        });

        DocumentReference cookRef = db.collection("Cooks").document(pr.getCookId());
        cookRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        String name = document.get("firstName").toString() + " " + document.get("lastName").toString();
                        String pic = document.get("pic").toString();
                        holder.cookName.setText(name);
                        Picasso.get().load(pic).resize(35, 35).centerCrop().into(holder.cookProfilePic);
                    }
                }
            }
        });
        DocumentReference mealRef = db.collection("Meals").document(pr.getMealId());
        mealRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        String name = document.get("mealName").toString();
                        String pic = document.get("pic").toString();
                        holder.mealName.setText(name);
                        Picasso.get().load(pic).resize(100, 100).centerCrop().into(holder.mealPic);
                    }
                }
            }
        });
        Calendar orderDate = Calendar.getInstance();
        orderDate.setTime(pr.getOrderDate().toDate());
        int month = orderDate.get(Calendar.MONTH) + 1;
        int day = orderDate.get(Calendar.DAY_OF_MONTH);
        int year = orderDate.get(Calendar.YEAR);
        String dateString = (
                String.format("%02d", month) +
                        " / " + String.format("%02d", day) + " / " +
                        year
        );
        holder.orderDate.setText(dateString);
        Calendar pickupDate = Calendar.getInstance();
        pickupDate.setTime(pr.getPickupTime().toDate());
        long currentTime = Calendar.getInstance().getTimeInMillis();
        long pickupTime = pickupDate.getTimeInMillis();
        long minutes = TimeTools.toMinutes(pickupTime - currentTime);
        if(minutes <= 0) {
            holder.pickupTime.setText((minutes * -1) + " min late");
            holder.pickupTime.setTextColor(Color.RED);
        } else {
            holder.pickupTime.setText(minutes + " min");
        }

    }

    @Override
    public int getItemCount() {
        return purchaseRequestList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView cookName;
        ImageView cookProfilePic;
        TextView address;
        TextView pickupTime;
        TextView orderDate;
        TextView mealName;
        TextView mealStatus;
        ImageView mealPic;
        Button viewDetailsBtn;
        Button pickupBtn;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cookName = (TextView) itemView.findViewById(R.id.tv_clientPendingOrderCookName);
            cookProfilePic = (ImageView) itemView.findViewById(R.id.iv_clientPendingOrderCookProfilePic);
            address = (TextView) itemView.findViewById(R.id.tv_clientPendingOrderAddress);
            pickupTime = (TextView) itemView.findViewById(R.id.tv_clientPendingOrderPickupTime);
            orderDate = (TextView) itemView.findViewById(R.id.tv_clientPendingOrderDate);
            mealName = (TextView) itemView.findViewById(R.id.tv_clientPendingMealName);
            mealStatus = (TextView) itemView.findViewById(R.id.tv_clientCurrentMealStatus);
            mealPic = (ImageView) itemView.findViewById(R.id.iv_clientPendingOrderMealPic);
            viewDetailsBtn = (Button) itemView.findViewById(R.id.btn_clientCurrentOrderViewDetailsBtn);
            pickupBtn = (Button) itemView.findViewById(R.id.btn_clientCurrentOrderPickupBtn);
        }
    }
}
