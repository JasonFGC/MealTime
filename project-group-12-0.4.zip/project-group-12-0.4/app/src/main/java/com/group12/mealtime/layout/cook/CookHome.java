package com.group12.mealtime.layout.cook;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.auth0.android.Auth0;
import com.auth0.android.authentication.AuthenticationException;
import com.auth0.android.callback.Callback;
import com.auth0.android.provider.WebAuthProvider;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.data.PurchaseRequest;
import com.group12.mealtime.layout.login.Login;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CookHome#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CookHome extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    List<PurchaseRequest> prList = new ArrayList<PurchaseRequest>();

    private RecyclerView prRecyclerView;
    private RecyclerView.Adapter prAdpater;
    private RecyclerView.LayoutManager prLayoutManager;

    private String cookId;

    private FirebaseFirestore db;

    public CookHome() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CookHome.
     */
    // TODO: Rename and change types and number of parameters
    public static CookHome newInstance(String param1, String param2) {
        CookHome fragment = new CookHome();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        cookId = this.getArguments().getString("cookId");
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cook_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        prRecyclerView = (RecyclerView) getView().findViewById(R.id.rv_currentOrders);


        prAdpater = new CookCurrentRecyclerViewAdapter(prList,getActivity());
        prRecyclerView.setAdapter(prAdpater);
        prLayoutManager = new LinearLayoutManager(getActivity());
        prRecyclerView.setHasFixedSize(true);

        prRecyclerView.setLayoutManager(prLayoutManager);


        prRecyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(getContext(), prRecyclerView ,new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {
                        // do whatever
                    }

                    @Override public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );

        db = FirebaseFirestore.getInstance();

        db.collection("PurchaseRequests")
                .whereEqualTo("cookId", cookId)
                .whereEqualTo("state","approved")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {

                    @Override
                    public void onEvent(@Nullable QuerySnapshot value,
                                        @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            Log.d("COMPAINTSs",e.toString());
                            return;
                        }

                        prList.clear();
                        for (QueryDocumentSnapshot doc : value) {
                            PurchaseRequest pr = new PurchaseRequest(doc.getId(), doc.getString("mealId"), doc.getString("clientId"), doc.getString("cookId"),(Timestamp) doc.get("pickupTime"),doc.getString("state"), (Timestamp) doc.get("orderDate"));
                            prList.add(pr);
                        }

                        prAdpater = new CookCurrentRecyclerViewAdapter(prList,getActivity());

                        prRecyclerView.setAdapter(prAdpater);
                    }
                });
    }
}