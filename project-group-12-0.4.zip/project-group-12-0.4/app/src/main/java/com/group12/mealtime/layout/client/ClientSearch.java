package com.group12.mealtime.layout.client;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;

import com.auth0.android.Auth0;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.group12.mealtime.R;
import com.group12.mealtime.data.Meal;
import com.group12.mealtime.data.PurchaseRequest;
import com.group12.mealtime.layout.cook.CookMealInfo;
import com.group12.mealtime.layout.cook.MealRecyclerViewAdapter;
import com.group12.mealtime.layout.cook.RecyclerItemClickListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ClientSearch#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ClientSearch extends Fragment {

    List<Meal> mealList = new ArrayList<Meal>();

    private RecyclerView mealRecyclerView;
    private RecyclerView.Adapter mealAdpater;
    private RecyclerView.LayoutManager mealLayoutManager;
    private EditText searchField;
    ListenerRegistration mealResults;

    private String clientId;

    private ImageView seachBtn;

    private FirebaseFirestore db;

    private String searchTerm = "";


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";



    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ClientSearch() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment client_search.
     */
    // TODO: Rename and change types and number of parameters
    public static ClientSearch newInstance(String param1, String param2) {
        ClientSearch fragment = new ClientSearch();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    private void searchName(){
        searchTerm = searchField.getText().toString();

        db.collection("Meals")
                .whereGreaterThanOrEqualTo("mealName",searchTerm)
                .whereLessThanOrEqualTo("mealName",searchTerm+"~")
                .whereEqualTo("offered",true)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            mealList.clear();
                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                Log.d("MEAL",doc.getId().toString());
                                Log.d("MEAL",doc.get("cuisineType").toString());
                                Log.d("MEAL",doc.get("description").toString());
                                Log.d("MEAL",doc.get("mealName").toString());
                                Log.d("MEAL",doc.get("mealType").toString());
                                Log.d("MEAL",String.valueOf((Boolean) doc.get("offered")));
                                Log.d("MEAL",doc.get("pic").toString());
                                Log.d("MEAL",String.valueOf((Double) doc.get("price")));
                                Meal m = new Meal(doc.getId().toString(), doc.get("cuisineType").toString(),doc.get("description").toString(),doc.get("mealName").toString(),doc.get("mealType").toString(),(Boolean) doc.get("offered"), doc.get("pic").toString(),(Double) doc.get("price"));
                                mealList.add(m);
                            }

                            mealRecyclerView.setAdapter(mealAdpater);
                        }
                    }
                });

    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mealRecyclerView = (RecyclerView) getView().findViewById(R.id.rv_featured_meals);


        mealAdpater = new MealSearchRecyclerViewAdapter(mealList,getActivity(), clientId);
        mealRecyclerView.setAdapter(mealAdpater);
        mealLayoutManager = new LinearLayoutManager(getActivity());
        mealRecyclerView.setHasFixedSize(true);

        mealRecyclerView.setLayoutManager(mealLayoutManager);

        db = FirebaseFirestore.getInstance();

        searchField = view.findViewById(R.id.mealSearch);
        seachBtn = view.findViewById(R.id.searchBtn);

        seachBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchName();
            }
        });
        searchField.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    searchName();

                    return true;
                }
                return false;
            }
        });





        db.collection("Meals")
                .whereGreaterThanOrEqualTo("mealName",searchTerm)
                .whereLessThanOrEqualTo("mealName",searchTerm+"~")
                .whereEqualTo("offered",true)
                .whereEqualTo("suspended",false)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {

                    @Override
                    public void onEvent(@Nullable QuerySnapshot value,
                                        @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            Log.d("COMPAINTSs",e.toString());
                            return;
                        }

                        mealList.clear();
                        for (QueryDocumentSnapshot doc : value) {
                            Log.d("MEAL",doc.getId().toString());
                            Log.d("MEAL",doc.get("cuisineType").toString());
                            Log.d("MEAL",doc.get("description").toString());
                            Log.d("MEAL",doc.get("mealName").toString());
                            Log.d("MEAL",doc.get("mealType").toString());
                            Log.d("MEAL",String.valueOf((Boolean) doc.get("offered")));
                            Log.d("MEAL",doc.get("pic").toString());
                            Log.d("MEAL",String.valueOf((Double) doc.get("price")));
                            Meal m = new Meal(doc.getId().toString(), doc.get("cuisineType").toString(),doc.get("description").toString(),doc.get("mealName").toString(),doc.get("mealType").toString(),(Boolean) doc.get("offered"), doc.get("pic").toString(),(Double) doc.get("price"));
                            mealList.add(m);
                        }

                        mealRecyclerView.setAdapter(mealAdpater);
                    }
                });


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        clientId = this.getArguments().getString("clientId");

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_client_search, container, false);
    }
}