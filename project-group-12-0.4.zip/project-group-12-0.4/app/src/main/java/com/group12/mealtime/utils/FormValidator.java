package com.group12.mealtime.utils;

public class FormValidator {

    public static boolean isInvalidName(String firstName) {
        return firstName.length() >= 20 || firstName.matches(".*\\d.*");
    }

    public static boolean isInvalidStreetNumber(String streetNumber) {
        return streetNumber.length() >= 6 || !streetNumber.matches("^[0-9]*$");
    }

    public static boolean isInvalidStreetName(String streetName) {
        return streetName.matches(".*\\d.*");
    }

    public static boolean isInvalidCity(String city) {
        return city.length() >= 85 || city.matches("[0-9]+");
    }

    public static boolean isInvalidPostalCode(String postalCode) {
        String postalCodeRegex = "^(?!.*[DFIOQU])[A-VXY][0-9][A-Z] ?[0-9][A-Z][0-9]$";
        return postalCode.length() >= 7 || !postalCode.matches(postalCodeRegex);
    }

    public static boolean isInvalidCreditCardNumber(String creditCardNumber) {
        String creditCardNumberRegex = "^(?:4[0-9]{12}(?:[0-9]{3})?|[25][1-7][0-9]{14}|6(?:011|5[0-" +
                "9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\\d{3})\\d{11})$";
        return creditCardNumber.length() >= 17 || !creditCardNumber.matches(creditCardNumberRegex);
    }

    public static boolean isInvalidCreditCardExpDate(String expDate) {
        String expDateRegex = "^[0-9]*$";
        return expDate.length() >= 5 || !expDate.matches(expDateRegex);
    }

    public static boolean isInvalidCvv(String cvv) {
        return cvv.length() >= 4 || !cvv.matches("[0-9]+");
    }

    public static boolean isInvalidDescription(String description) {
        return description.length() >= 50;
    }

    public static boolean isInvalidMealName(String mealName) {
        return mealName.length() > 15;
    }

    public static boolean isInvalidMealType(String mealType) {
        return mealType.length() > 10;
    }

    public static boolean isInvalidCuisineType(String cuisineType) {
        return cuisineType.length() > 10;
    }

    public static boolean isInvalidMealPrice(String mealPrice) {
        try {
            Double.parseDouble(mealPrice);
            return false;
        } catch(NumberFormatException e) {
            return true;
        }
    }

    public static boolean isInvalidMealDescription(String mealDescription) {
        return mealDescription.length() > 100;
    }

    public static boolean isInvalidMealListItem(String mealListItem) {
        return mealListItem.length() > 15;
    }
}
